/* Node al Pettine: interfaccia. Una sola fonte di verità (lo stato del form): l'HTML, il server,
   e le spiegazioni ne derivano a ogni modifica.
   Usa window.Pettine (lib/genera.js), window.creaZip (lib/zip.js), SERVER_TPL e PICO_CSS (incorporati dal build). */
(function () {
  'use strict';
  document.documentElement.classList.add('js');
  const P = window.Pettine;
  const $ = s => document.querySelector(s);
  const CHIAVE = 'node-al-pettine:v2';
  const riduciMoto = matchMedia('(prefers-reduced-motion: reduce)');

  // ---------------------------------------------------------------- regole: ordine, glifi, ricerca
  const ORDINE = ['libero', 'nonnumerico', 'lettere', 'maiuscola', 'alfanumerico', 'email', 'telefonoGen', 'telefono', 'cifre', 'soloCifre', 'cap', 'data', 'maggiorenne', 'ora', 'intero', 'decimale', 'prezzo', 'lunghezza', 'elenco', 'uguale', 'username', 'password', 'cf', 'piva', 'iban', 'targa', 'provincia', 'civico', 'url', 'ipv4', 'mac', 'regex'];
  const GLIFO = { libero: 'abc', nonnumerico: 'a≠1', lettere: 'Aa', email: '@', telefonoGen: 'tel', telefono: '+39', cifre: '123', cap: 'CAP', data: '31/', intero: '±1', decimale: '1,5', lunghezza: '|n|', cf: 'CF', piva: 'IVA', targa: 'AB1', password: '***', regex: '/.*/', alfanumerico: 'a1', maiuscola: 'Ab', soloCifre: '0-9', elenco: '{ }', uguale: '=', maggiorenne: '18+', ora: '12:', url: 'www', iban: 'IT', provincia: 'PR', civico: 'n.', ipv4: 'IP', mac: 'MAC', username: 'usr', prezzo: '€' };
  const PAROLE = {
    libero: 'nessun controllo testo qualsiasi note libero',
    nonnumerico: 'nome cognome testo non numero non numerico citta',
    lettere: 'nome cognome citta solo lettere alfabetico',
    email: 'mail posta indirizzo chiocciola',
    telefonoGen: 'telefono fisso numero tel',
    telefono: 'cellulare mobile smartphone numero',
    cifre: 'matricola codice numerico cifre numero esatto',
    cap: 'codice postale cap',
    data: 'data nascita giorno mese anno gg mm aaaa',
    intero: 'eta anni quantita numero intero range minimo massimo voto',
    decimale: 'prezzo importo altezza peso decimale virgola',
    lunghezza: 'caratteri lunghezza minimo massimo username lungo corto',
    cf: 'codice fiscale cf',
    piva: 'partita iva azienda',
    targa: 'auto macchina veicolo',
    password: 'password parola chiave sicura',
    regex: 'regex personalizzata pattern formato espressione regolare',
    alfanumerico: 'alfanumerico lettere cifre codice senza spazi',
    maiuscola: 'iniziale maiuscola nome proprio cognome citta capitalizzato',
    soloCifre: 'solo cifre numerico zeri iniziali codice numero',
    elenco: 'valori ammessi elenco lista scelta sesso m f stato civile celibe coniugato si no opzioni enum',
    uguale: 'uguale conferma password email ripeti coincide stesso altro campo',
    maggiorenne: 'maggiorenne eta minima data di nascita 18 anni',
    ora: 'ora orario hh mm tempo',
    url: 'url sito web indirizzo internet http https link',
    iban: 'iban conto corrente banca bonifico',
    provincia: 'provincia sigla pr mi rm',
    civico: 'numero civico indirizzo via casa',
    ipv4: 'indirizzo ip ipv4 rete network host',
    mac: 'indirizzo mac scheda di rete esadecimale',
    username: 'username utente nickname login account',
    prezzo: 'prezzo euro importo costo soldi decimali',
  };
  const PARAM_ET = { righe: 'Righe (rows)', colonne: 'Colonne (cols)', opzioni: 'Opzioni, una per riga: valore = testo', min: 'Minimo', max: 'Massimo', cifre: 'Cifre', anni: 'Anni minimi', valori: 'Valori ammessi, separati da virgola', campo: 'Uguale al campo', pattern: 'Pattern (regex)', messaggio: 'Messaggio di errore' };
  const VOCI_TIPO = [
    { key: 't:area', tipo: 'area', nome: 'Area di testo', descr: 'testo lungo (textarea)', glifo: 'txt', parole: 'area di testo textarea note richieste particolari commento messaggio descrizione lungo' },
    { key: 't:menu', tipo: 'menu', nome: 'Menu a tendina', descr: 'scrivi tu le opzioni (select)', glifo: 'sel', parole: 'menu a tendina select dropdown lista opzioni scegli' },
    { key: 't:menu:regioni', tipo: 'menu', preset: 'regioni', nome: 'Menu a tendina: regioni', descr: 'le 20 regioni italiane', glifo: 'sel', parole: 'regione regioni residenza italia menu select dropdown' },
    { key: 't:menu:province', tipo: 'menu', preset: 'province', nome: 'Menu a tendina: province', descr: '107 sigle (verifica la Sardegna)', glifo: 'sel', parole: 'provincia province sigla residenza menu select dropdown' },
    { key: 't:radio', tipo: 'radio', nome: 'Scelta singola', descr: 'scrivi tu le opzioni (radio)', glifo: '( )', parole: 'radio scelta singola opzione una bottoni' },
    { key: 't:radio:sesso', tipo: 'radio', preset: 'sesso', nome: 'Scelta singola: sesso', descr: 'M o F', glifo: '( )', parole: 'sesso genere m f maschio femmina radio' },
    { key: 't:radio:sino', tipo: 'radio', preset: 'sino', nome: 'Scelta singola: sì o no', descr: 'si, no', glifo: '( )', parole: 'si no sì radio scelta conferma' },
    { key: 't:radio:civile', tipo: 'radio', preset: 'civile', nome: 'Scelta singola: stato civile', descr: 'celibe, coniugato, vedovo, divorziato', glifo: '( )', parole: 'stato civile celibe nubile coniugato sposato vedovo divorziato radio' },
    { key: 't:caselle', tipo: 'caselle', nome: 'Caselle multiple', descr: 'zero o più scelte (checkbox)', glifo: '[x]', parole: 'caselle checkbox multiple hobby interessi spunta piu scelte' },
    { key: 't:multipla', tipo: 'multipla', nome: 'Lista a scelta multipla', descr: 'più voci da un elenco (select multiple)', glifo: 'sel+', parole: 'lista scelta multipla select multiple piu voci' },
    { key: 't:casella', tipo: 'casella', nome: 'Casella singola', descr: 'da spuntare, es. privacy', glifo: '[ ]', parole: 'casella checkbox privacy consenso accetto termini spunta singola' },
  ];
  const VOCI = ORDINE.map(id => ({ key: 'r:' + id, tipo: 'testo', regola: id, nome: P.REGOLE[id].nome, descr: P.REGOLE[id].descr, glifo: GLIFO[id], parole: PAROLE[id] })).concat(VOCI_TIPO);
  const chiaveDi = c => (c.tipo || 'testo') === 'testo' ? 'r:' + c.regola : (VOCI_TIPO.find(v => v.tipo === c.tipo && v.preset && P.PRESET[v.preset] === c.opzioni) || { key: 't:' + c.tipo }).key;
  const voceDi = c => VOCI.find(v => v.key === chiaveDi(c)) || VOCI[0];
  const norm = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

  // ---------------------------------------------------------------- stato
  let prog = 0;
  const nuovoId = () => 'c' + (++prog) + Math.random().toString(36).slice(2, 6);
  function campo(over) {
    return Object.assign({ id: nuovoId(), etichetta: '', nome: '', nomeManuale: false, tipo: 'testo', regola: 'libero', presenza: 'obbligatorio', min: '', max: '', cifre: '5', anni: '18', valori: '', campo: '', pattern: '', messaggio: '', opzioni: '', righe: '4', colonne: '40' }, over);
  }
  function esempio() {
    return {
      titolo: 'Contatti', azione: '/recuperadati', metodo: 'post', statici: 'pipe', tema: 'light', errori: 'pagina', ricompila: true, bottone: 'Invia', reset: true,
      campi: [
        campo({ etichetta: 'Cognome', nome: 'cognome', regola: 'nonnumerico' }),
        campo({ etichetta: 'Nome', nome: 'nome', regola: 'nonnumerico' }),
        campo({ etichetta: 'Matricola', nome: 'matricola', regola: 'cifre', cifre: '5' }),
        campo({ etichetta: 'Email', nome: 'email', regola: 'email', presenza: 'gruppo' }),
        campo({ etichetta: 'Telefono', nome: 'telefono', regola: 'telefonoGen', presenza: 'gruppo' }),
        campo({ etichetta: 'Data di nascita', nome: 'data_di_nascita', regola: 'data', presenza: 'facoltativo' }),
      ],
    };
  }
  let form = esempio();
  try {
    const s = JSON.parse(localStorage.getItem(CHIAVE) || 'null');
    if (s && Array.isArray(s.campi)) { form = s; form.campi = form.campi.map(c => campo(Object.assign({}, c, { id: nuovoId() }))); }
  } catch (e) { /* si riparte dall'esempio */ }
  const salva = () => { try { localStorage.setItem(CHIAVE, JSON.stringify(form)); } catch (e) { /* niente */ } };

  // annulla: una sola istantanea, per le azioni che tolgono lavoro
  let istantanea = null;
  function fotografa() { istantanea = JSON.stringify(form); }
  function annulla() {
    if (!istantanea) return;
    form = JSON.parse(istantanea);
    form.campi = form.campi.map(c => campo(Object.assign({}, c, { id: nuovoId() })));
    istantanea = null;
    tuttoDaCapo();
    avviso('Ripristinato.');
  }

  // ---------------------------------------------------------------- utilità
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  function rimanda(fn, ms) { let t; return () => { clearTimeout(t); t = setTimeout(fn, ms); }; }
  let tAvviso;
  function avviso(testo, conAnnulla) {
    const el = $('#avviso');
    el.innerHTML = '<span></span>' + (conAnnulla ? '<button type="button" data-annulla>Annulla</button>' : '');
    el.firstChild.textContent = testo;
    el.classList.add('visibile');
    clearTimeout(tAvviso);
    tAvviso = setTimeout(() => el.classList.remove('visibile'), conAnnulla ? 6000 : 2800);
  }
  $('#avviso').addEventListener('click', e => { if (e.target.matches('[data-annulla]')) { $('#avviso').classList.remove('visibile'); annulla(); } });
  async function copia(testo, cosa) {
    try { await navigator.clipboard.writeText(testo); }
    catch (e) {
      const t = document.createElement('textarea');
      t.value = testo; t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy'); t.remove();
      if (!ok) { avviso('Copia non riuscita: seleziona il codice e usa Ctrl+C.'); return; }
    }
    avviso(cosa + ' copiato.');
  }
  const SVG = {
    su: '<path d="M8 13V3M3.5 7.5 8 3l4.5 4.5"/>',
    giu: '<path d="M8 3v10M3.5 8.5 8 13l4.5-4.5"/>',
    via: '<path d="M4 4l8 8M12 4l-8 8"/>',
  };
  const svg = n => `<svg viewBox="0 0 16 16" aria-hidden="true">${SVG[n]}</svg>`;

  // ---------------------------------------------------------------- evidenziazione (monocroma)
  const RE_JS = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|(`(?:\\[\s\S]|[^`\\])*`|'(?:\\.|[^'\\\n])*'|"(?:\\.|[^"\\\n])*")|(\/(?![*/\s])(?:\\.|\[(?:\\.|[^\]\\\n])*\]|[^/\\\n[])+\/[gimsuy]*)|\b(const|let|var|function|return|if|else|for|of|in|switch|case|break|default|new|require|try|catch|typeof|true|false|null|undefined)\b|\b(\d+(?:\.\d+)?)\b/g;
  const RE_HTML = /(<!-{2}[\s\S]*?-{2}>)|(<\/?)([\w!-]+)|("[^"]*")|(\s)([\w-]+)(?==)|(\/?>)/g;
  function segmenti(testo, re, mappa) {
    const out = []; let ultimo = 0, m;
    re.lastIndex = 0;
    while ((m = re.exec(testo))) {
      if (m.index > ultimo) out.push(['', testo.slice(ultimo, m.index)]);
      mappa(m, out);
      ultimo = re.lastIndex;
    }
    out.push(['', testo.slice(ultimo)]);
    return out;
  }
  const mappaJs = (m, out) => out.push([m[1] ? 'c' : m[2] || m[3] ? 's' : m[4] ? 'k' : 'n', m[0]]);
  const mappaHtml = (m, out) => {
    if (m[1]) out.push(['c', m[1]]);
    else if (m[2]) { out.push(['', m[2]]); out.push(['t', m[3]]); }
    else if (m[4]) out.push(['s', m[4]]);
    else if (m[5]) { out.push(['', m[5]]); out.push(['a', m[6]]); }
    else out.push(['', m[7]]);
  };
  function righe(seg) {
    const r = [[]];
    for (const [cls, t] of seg) t.split('\n').forEach((p, i) => {
      if (i) r.push([]);
      if (p) r[r.length - 1].push(cls ? `<span class="${cls}">${esc(p)}</span>` : esc(p));
    });
    if (r.length > 1 && !r[r.length - 1].length) r.pop();
    return r.map(x => `<span class="r">${x.join('') || ' '}</span>`).join('');
  }

  // ---------------------------------------------------------------- nodi
  function controlla() {
    let n = 0;
    const nomi = form.campi.map(c => c.nome);
    for (const c of form.campi) {
      c.errore = '';
      if (!String(c.etichetta).trim()) c.errore = 'Etichetta vuota: scrivi il testo della label (es. Cognome).';
      else if (!/^[A-Za-z_][\w-]*$/.test(c.nome)) c.errore = 'Il name deve iniziare con una lettera e contenere solo lettere, cifre, _ e -.';
      else if (nomi.filter(x => x === c.nome).length > 1) c.errore = `name «${c.nome}» ripetuto: al server arriverebbero due valori con lo stesso nome. Rendilo univoco.`;
      else if ((c.tipo || 'testo') !== 'testo') {
        const op = P.opzioniDi(c), valori = op.map(o => o.valore);
        if (P.conOpzioni(c) && op.length < 2) c.errore = 'Scrivi almeno due opzioni, una per riga (es. PR = Parma).';
        else if (new Set(valori).size !== valori.length) c.errore = 'Due opzioni hanno lo stesso valore: il server non le distinguerebbe.';
        else if (c.tipo === 'casella' && c.presenza === 'gruppo') c.errore = '«Almeno uno» non vale per una casella singola: scegli Da spuntare o Facoltativo.';
      }
      else if (c.regola === 'regex') {
        if (!String(c.pattern).trim()) c.errore = 'Pattern vuoto: scrivi la regex che il campo deve rispettare.';
        else { try { P.letteraleRegex(c.pattern); } catch (e) { c.errore = 'Regex non valida (' + e.message.replace(/^Invalid regular expression: /, '') + '). Controlla parentesi e quantificatori.'; } }
      }
      else if (c.regola === 'elenco' && P.valoriDi(c).length < 2) c.errore = 'Scrivi almeno due valori ammessi, separati da virgola (es. M, F).';
      else if (c.regola === 'uguale' && (!c.campo || !form.campi.some(x => x !== c && x.nome === c.campo))) c.errore = 'Scegli il campo a cui deve essere uguale (es. Password).';
      if (c.errore) n++;
    }
    const gruppo = form.campi.filter(c => c.presenza === 'gruppo' && c.tipo !== 'casella');
    if (gruppo.length === 1 && !gruppo[0].errore) { gruppo[0].errore = '«Almeno uno» serve su due o più campi (es. email o telefono). Sceglilo anche su un altro campo.'; n++; }
    if (!form.campi.length) n++;
    return n;
  }

  // ---------------------------------------------------------------- registro
  const registro = $('#registro');
  function parametri(c) {
    const t = c.tipo || 'testo';
    let lista;
    if (t === 'testo') lista = (P.REGOLE[c.regola] || P.REGOLE.libero).parametri || [];
    else if (t === 'area') lista = ['righe', 'colonne', 'min', 'max'];
    else if (t === 'menu' || t === 'radio') lista = ['opzioni'];
    else if (t === 'caselle' || t === 'multipla') lista = ['opzioni', 'min', 'max'];
    else lista = [];
    return lista.map(p => {
      if (p === 'opzioni') {
        const n = P.opzioniDi(c).length;
        return `<label class="campo campo--opzioni"><span class="cella__et">${PARAM_ET.opzioni} (${n})</span><textarea data-k="opzioni" rows="${Math.min(Math.max(n, 3), 6)}" spellcheck="false" placeholder="PR = Parma&#10;RE = Reggio Emilia">${esc(c.opzioni || '')}</textarea></label>`;
      }
      let et = PARAM_ET[p];
      if ((t === 'area' || c.regola === 'lunghezza') && (p === 'min' || p === 'max')) et = p === 'min' ? 'Caratteri min' : 'Caratteri max';
      if ((t === 'caselle' || t === 'multipla') && (p === 'min' || p === 'max')) et = p === 'min' ? 'Scelte min' : 'Scelte max';
      const largo = ['pattern', 'messaggio', 'valori'].includes(p) ? ' campo--largo' : '';
      if (p === 'campo') {
        const altri = form.campi.filter(x => x !== c);
        return `<label class="campo"><span class="cella__et">${et}</span><select data-k="campo"><option value="">scegli il campo</option>${altri.map(x => `<option value="${esc(x.nome)}"${x.nome === c.campo ? ' selected' : ''}>${esc(x.etichetta || x.nome)} (${esc(x.nome)})</option>`).join('')}</select></label>`;
      }
      const extra = p === 'pattern' ? ' class="mono" placeholder="es. [A-Z]{3}-\\d{2}"' : p === 'messaggio' ? ' placeholder="facoltativo"' : p === 'valori' ? ' placeholder="es. M, F"' : ' inputmode="numeric"';
      return `<label class="campo${largo}"><span class="cella__et">${et}</span><input type="text" data-k="${p}" value="${esc(c[p] || '')}"${extra} spellcheck="false" autocomplete="off"></label>`;
    }).join('');
  }
  function riga(c, i, n) {
    const v = voceDi(c), t = c.tipo || 'testo';
    const l = esc(c.etichetta || 'campo ' + (i + 1));
    return `<li class="riga${c.errore ? ' ha-nodo' : ''}" data-id="${c.id}">
      <button type="button" class="maniglia" data-maniglia aria-label="Sposta ${l}, posizione ${i + 1} di ${n}: trascina, oppure frecce su e giù" title="Trascina per spostare"><span class="maniglia__n">${i + 1}</span><svg viewBox="0 0 8 14" aria-hidden="true"><circle cx="2" cy="2" r="1"/><circle cx="6" cy="2" r="1"/><circle cx="2" cy="7" r="1"/><circle cx="6" cy="7" r="1"/><circle cx="2" cy="12" r="1"/><circle cx="6" cy="12" r="1"/></svg></button>
      <label class="campo-registro"><span class="et-mobile">Etichetta</span><input type="text" data-k="etichetta" value="${esc(c.etichetta)}" placeholder="es. Cognome" aria-label="Etichetta del campo ${i + 1}" autocomplete="off"></label>
      <label class="campo-registro"><span class="et-mobile">name</span><input type="text" class="mono" data-k="nome" value="${esc(c.nome)}" aria-label="name di ${l}" spellcheck="false" autocomplete="off"></label>
      <div class="campo-registro campo-registro--regola"><span class="et-mobile">Tipo e controllo</span>
        <button type="button" class="scelta" data-scelta aria-haspopup="listbox" aria-expanded="false" aria-label="Tipo e controllo di ${l}: ${esc(v.nome)}"><span class="glifo" aria-hidden="true">${esc(v.glifo)}</span><span class="scelta__nome">${esc(v.nome)}</span></button>
      </div>
      <label class="campo-registro"><span class="et-mobile">Presenza</span><select data-k="presenza" aria-label="Presenza di ${l}">
        <option value="obbligatorio"${c.presenza === 'obbligatorio' ? ' selected' : ''}>${t === 'casella' ? 'Da spuntare' : 'Obbligatorio'}</option>
        <option value="facoltativo"${c.presenza === 'facoltativo' ? ' selected' : ''}>Facoltativo</option>
        <option value="gruppo"${c.presenza === 'gruppo' ? ' selected' : ''}>Almeno uno</option>
      </select></label>
      <div class="azioni">
        <button class="icona" type="button" data-azione="via" aria-label="Elimina ${l}" title="Elimina">${svg('via')}</button>
      </div>
      <div class="riga__extra">${parametri(c)}</div>
      ${c.errore ? `<p class="nodo"><span class="nodo-tag">Nodo</span><span>${esc(c.errore)}</span></p>` : ''}
    </li>`;
  }
  function disegnaRegistro() {
    controlla();
    registro.innerHTML = form.campi.length
      ? form.campi.map((c, i) => riga(c, i, form.campi.length)).join('')
      : '<li class="vuoto">Nessun campo. Aggiungine uno o carica l\'esempio Contatti.</li>';
  }
  // aggiorna solo il nodo di una riga, senza ridisegnarla (il focus resta dov'è)
  function aggiornaNodi() {
    controlla();
    form.campi.forEach(c => {
      const li = registro.querySelector(`[data-id="${c.id}"]`);
      if (!li) return;
      li.classList.toggle('ha-nodo', !!c.errore);
      let p = li.querySelector('.nodo');
      if (c.errore) {
        if (!p) { p = document.createElement('p'); p.className = 'nodo'; p.innerHTML = '<span class="nodo-tag">Nodo</span><span></span>'; li.appendChild(p); }
        p.lastChild.textContent = c.errore;
      } else if (p) p.remove();
    });
  }
  function nomeUnico(base, escluso) {
    let n = base || 'campo', i = 2;
    while (form.campi.some(c => c !== escluso && c.nome === n)) n = (base || 'campo') + '_' + i++;
    return n;
  }
  const trova = el => { const li = el.closest('[data-id]'); return li && form.campi.find(c => c.id === li.dataset.id); };

  registro.addEventListener('input', e => {
    const k = e.target.dataset.k, c = trova(e.target);
    if (!k || !c) return;
    c[k] = e.target.value;
    if (k === 'etichetta' && !c.nomeManuale) {
      c.nome = nomeUnico(P.slug(c.etichetta), c);
      e.target.closest('li').querySelector('[data-k="nome"]').value = c.nome;
    }
    if (k === 'nome') c.nomeManuale = true;
    aggiornaNodi();
    aggiorna();
  });
  registro.addEventListener('change', e => { if (e.target.matches('select[data-k]')) { const c = trova(e.target); c[e.target.dataset.k] = e.target.value; aggiornaNodi(); aggiorna(); } });
  registro.addEventListener('keydown', e => {
    if (e.key !== 'Enter' || !e.target.matches('[data-k="etichetta"]')) return;
    e.preventDefault();
    const i = form.campi.indexOf(trova(e.target));
    if (i === form.campi.length - 1) aggiungi();
    else registro.querySelectorAll('[data-k="etichetta"]')[i + 1].focus();
  });
  registro.addEventListener('click', e => {
    const b = e.target.closest('[data-azione]');
    if (!b) return;
    const c = trova(b), i = form.campi.indexOf(c);
    if (b.dataset.azione === 'via') {
      fotografa();
      form.campi.splice(i, 1);
      tuttoDaCapo();
      avviso(`Campo «${c.etichetta || c.nome}» eliminato.`, true);
      const dopo = registro.querySelectorAll('[data-k="etichetta"]')[Math.min(i, form.campi.length - 1)];
      (dopo || $('#btn-aggiungi')).focus();
      return;
    }
  });

  // ---------------------------------------------------------------- trascina per riordinare (e frecce sulla maniglia)
  function sposta(c, j) {
    const i = form.campi.indexOf(c);
    if (j < 0 || j >= form.campi.length || j === i) return;
    form.campi.splice(j, 0, form.campi.splice(i, 1)[0]);
    tuttoDaCapo();
    registro.querySelector(`[data-id="${c.id}"] [data-maniglia]`).focus();
    avviso(`«${c.etichetta || c.nome}» in posizione ${j + 1} di ${form.campi.length}.`);
  }
  registro.addEventListener('keydown', e => {
    const m = e.target.closest('[data-maniglia]');
    if (!m || !['ArrowUp', 'ArrowDown'].includes(e.key)) return;
    e.preventDefault();
    const c = trova(m);
    sposta(c, form.campi.indexOf(c) + (e.key === 'ArrowUp' ? -1 : 1));
  });
  let presa = null;
  function scivola(el, primaTop) {
    if (riduciMoto.matches) return;
    const delta = primaTop - el.getBoundingClientRect().top;
    if (!delta) return;
    el.style.transition = 'none';
    el.style.transform = `translateY(${delta}px)`;
    void el.offsetWidth;
    el.style.transition = '';
    el.style.transform = '';
  }
  registro.addEventListener('pointerdown', e => {
    const m = e.target.closest('[data-maniglia]');
    if (!m || e.button !== 0) return;
    e.preventDefault();
    m.focus();
    m.setPointerCapture(e.pointerId);
    const li = m.closest('li');
    presa = { li, m, presa: e.clientY - li.getBoundingClientRect().top, ty: 0, mosso: false, y0: e.clientY };
  });
  registro.addEventListener('pointermove', e => {
    if (!presa) return;
    if (!presa.mosso && Math.abs(e.clientY - presa.y0) < 4) return;
    if (!presa.mosso) { presa.mosso = true; presa.li.classList.add('in-presa'); chiudi(false); }
    const li = presa.li;
    li.style.transform = '';
    const righe = [...registro.querySelectorAll(':scope > li[data-id]')];
    const i = righe.indexOf(li), prima = righe[i - 1], dopo = righe[i + 1];
    const mezzo = el => el.getBoundingClientRect().top + el.offsetHeight / 2;
    if (dopo && e.clientY > mezzo(dopo)) { const t = dopo.getBoundingClientRect().top; dopo.after(li); scivola(dopo, t); }
    else if (prima && e.clientY < mezzo(prima)) { const t = prima.getBoundingClientRect().top; prima.before(li); scivola(prima, t); }
    // la riga segue il puntatore: posizione naturale più lo scarto
    presa.ty = e.clientY - presa.presa - li.getBoundingClientRect().top;
    li.style.transform = `translateY(${presa.ty}px)`;
  });
  function lascia() {
    if (!presa) return;
    const { li, mosso } = presa;
    presa = null;
    li.classList.remove('in-presa');
    li.style.transform = '';
    if (!mosso) return;
    const ordine = [...registro.querySelectorAll(':scope > li[data-id]')].map(x => x.dataset.id);
    const c = form.campi.find(x => x.id === li.dataset.id);
    const prima = form.campi.indexOf(c);
    form.campi.sort((a, b) => ordine.indexOf(a.id) - ordine.indexOf(b.id));
    tuttoDaCapo();
    registro.querySelector(`[data-id="${c.id}"] [data-maniglia]`).focus();
    const dopo = form.campi.indexOf(c);
    if (dopo !== prima) avviso(`«${c.etichetta || c.nome}» in posizione ${dopo + 1} di ${form.campi.length}.`);
  }
  registro.addEventListener('pointerup', lascia);
  registro.addEventListener('pointercancel', lascia);
  function aggiungi() {
    const c = campo({ nome: nomeUnico('campo' + (form.campi.length + 1)) });
    form.campi.push(c);
    tuttoDaCapo();
    registro.querySelector(`[data-id="${c.id}"] [data-k="etichetta"]`).focus();
  }
  $('#btn-aggiungi').addEventListener('click', aggiungi);
  $('#btn-svuota').addEventListener('click', () => {
    if (!form.campi.length) return;
    fotografa(); form.campi = []; tuttoDaCapo(); avviso('Campi tolti.', true);
  });
  $('#btn-completo').addEventListener('click', () => {
    fotografa();
    const e = P.esempioCompleto();
    form = Object.assign({}, e, { campi: e.campi.map(c => campo(Object.assign({ nomeManuale: true }, c))) });
    tuttoDaCapo();
    avviso(`Esempio completo: ${form.campi.length} campi, un tipo e un controllo per ciascuno.`, true);
  });
  $('#btn-esempio').addEventListener('click', () => {
    fotografa(); form = esempio(); tuttoDaCapo(); avviso('Esempio Contatti caricato.', true);
  });

  // ---------------------------------------------------------------- il menu delle regole, cercabile
  const sel = document.createElement('div');
  sel.className = 'selettore'; sel.hidden = true;
  sel.innerHTML = '<div class="selettore__cerca"><input type="search" role="combobox" aria-expanded="true" aria-controls="sel-lista" aria-autocomplete="list" aria-label="Cerca un controllo" placeholder="Cerca: provincia, email, sesso, matricola…" autocomplete="off" spellcheck="false"></div><ul class="selettore__lista" id="sel-lista" role="listbox" aria-label="Controlli lato server"></ul>';
  document.body.appendChild(sel);
  const cerca = sel.querySelector('input'), lista = sel.querySelector('ul');
  let selCampo = null, selBottone = null, risultati = [], attivo = 0;

  function filtra() {
    const q = norm(cerca.value.trim());
    const parole = q.split(/\s+/).filter(Boolean);
    risultati = VOCI.filter(v => {
      const testo = norm([v.nome, v.descr, v.parole, v.glifo].join(' '));
      return parole.every(p => testo.includes(p));
    }).map(v => v.key);
    const voce = k => VOCI.find(v => v.key === k);
    // prima chi ha la parola nel nome, poi gli elenchi pronti (province, regioni, sesso)
    const punti = k => (norm(voce(k).nome).includes(parole[0]) ? 2 : 0) + (voce(k).preset ? 1 : 0);
    if (parole.length) risultati.sort((a, b) => punti(b) - punti(a));
    attivo = Math.max(0, risultati.indexOf(selCampo && chiaveDi(selCampo)));
    if (parole.length) attivo = 0;
    lista.innerHTML = risultati.length
      ? risultati.map((k, i) => {
          const v = voce(k);
          const testa = !parole.length && (k === 'r:libero' || k === VOCI_TIPO[0].key) ? `<li class="selettore__gruppo" role="presentation">${k === 'r:libero' ? 'Campo di testo, con un controllo' : 'Altri controlli del form'}</li>` : '';
          return `${testa}<li role="option" id="opz-${i}" class="opzione${i === attivo ? ' attiva' : ''}" data-voce="${k}" aria-selected="${selCampo && chiaveDi(selCampo) === k}"><span class="glifo" aria-hidden="true">${esc(v.glifo)}</span><span class="opzione__nome">${esc(v.nome)}</span><span class="opzione__descr">${esc(v.descr)}</span></li>`;
        }).join('')
      : '<li class="selettore__vuoto" role="presentation">Nessun controllo con questo nome. Prova «Regex personalizzata» per un formato tuo.</li>';
    segnaAttivo();
  }
  function segnaAttivo() {
    lista.querySelectorAll('.opzione').forEach((o, i) => o.classList.toggle('attiva', i === attivo));
    const o = lista.querySelectorAll('.opzione')[attivo];
    cerca.setAttribute('aria-activedescendant', o ? o.id : '');
    if (o) o.scrollIntoView({ block: 'nearest' });
  }
  function posiziona() {
    if (!selBottone) return;
    const r = selBottone.getBoundingClientRect();
    const w = Math.min(340, innerWidth - 16);
    const left = Math.min(Math.max(8, r.left), innerWidth - w - 8);
    const sotto = innerHeight - r.bottom, sopra = r.top;
    sel.style.left = left + 'px';
    if (sotto < 300 && sopra > sotto) { sel.style.top = ''; sel.style.bottom = (innerHeight - r.top + 4) + 'px'; }
    else { sel.style.bottom = ''; sel.style.top = (r.bottom + 4) + 'px'; }
  }
  function apri(bottone, iniziale) {
    selBottone = bottone; selCampo = trova(bottone);
    bottone.setAttribute('aria-expanded', 'true');
    sel.hidden = false;
    cerca.value = iniziale || '';
    filtra(); posiziona();
    cerca.focus();
  }
  function chiudi(rimettiFocus) {
    if (sel.hidden) return;
    sel.hidden = true;
    if (selBottone) { selBottone.setAttribute('aria-expanded', 'false'); if (rimettiFocus) selBottone.focus(); }
    selBottone = null; selCampo = null;
  }
  function scegli(k) {
    if (!selCampo || !k) return;
    const c = selCampo, v = VOCI.find(x => x.key === k);
    if (v.tipo === 'testo') { c.tipo = 'testo'; c.regola = v.regola; }
    else {
      c.tipo = v.tipo; c.regola = 'libero';
      if (v.preset && c.opzioni && c.opzioni !== P.PRESET[v.preset]) { fotografa(); avviso('Opzioni sostituite con l\'elenco pronto.', true); }
      if (v.preset) c.opzioni = P.PRESET[v.preset];
      if (v.tipo === 'caselle') c.presenza = c.presenza === 'obbligatorio' ? 'facoltativo' : c.presenza;
    }
    chiudi(false);
    tuttoDaCapo();
    const li = registro.querySelector(`[data-id="${c.id}"]`);
    (li.querySelector('.riga__extra input') || li.querySelector('[data-scelta]')).focus();
  }
  registro.addEventListener('click', e => { const b = e.target.closest('[data-scelta]'); if (b) (sel.hidden || selBottone !== b) ? apri(b) : chiudi(true); });
  registro.addEventListener('keydown', e => {
    const b = e.target.closest('[data-scelta]');
    if (!b) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); apri(b); }
    else if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey && e.key !== ' ') { e.preventDefault(); apri(b, e.key); }
  });
  cerca.addEventListener('input', filtra);
  cerca.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); attivo = Math.min(attivo + 1, risultati.length - 1); segnaAttivo(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); attivo = Math.max(attivo - 1, 0); segnaAttivo(); }
    else if (e.key === 'Enter') { e.preventDefault(); scegli(risultati[attivo]); }
    else if (e.key === 'Escape') { e.preventDefault(); chiudi(true); }
    else if (e.key === 'Tab') chiudi(false);
  });
  lista.addEventListener('mousedown', e => e.preventDefault());
  lista.addEventListener('click', e => { const o = e.target.closest('[data-voce]'); if (o) scegli(o.dataset.voce); });
  document.addEventListener('mousedown', e => { if (!sel.hidden && !sel.contains(e.target) && !e.target.closest('[data-scelta]')) chiudi(false); });
  addEventListener('resize', () => chiudi(false));
  addEventListener('scroll', posiziona, { passive: true });

  // ---------------------------------------------------------------- impostazioni
  function impostazioni() {
    $('#f-titolo').value = form.titolo;
    $('#f-azione').value = form.azione;
    $('#f-bottone').value = form.bottone;
    $('#f-reset').checked = !!form.reset;
    document.querySelectorAll('input[name="f-metodo"]').forEach(r => { r.checked = r.value === form.metodo; });
    document.querySelectorAll('input[name="f-statici"]').forEach(r => { r.checked = r.value === (form.statici || 'pipe'); });
    document.querySelectorAll('input[name="f-tema"]').forEach(r => { r.checked = r.value === P.temaDi(form); });
    document.querySelectorAll('input[name="f-errori"]').forEach(r => { r.checked = r.value === P.erroriDi(form); });
    $('#f-ricompila').checked = form.ricompila !== false;
    $('#f-ricompila').disabled = P.erroriDi(form) !== 'campo';
  }
  $('#f-titolo').addEventListener('input', e => { form.titolo = e.target.value; aggiorna(); });
  $('#f-azione').addEventListener('input', e => { form.azione = e.target.value; aggiorna(); });
  $('#f-bottone').addEventListener('input', e => { form.bottone = e.target.value; aggiorna(); });
  $('#f-reset').addEventListener('change', e => { form.reset = e.target.checked; aggiorna(); });
  document.querySelectorAll('input[name="f-metodo"]').forEach(r => r.addEventListener('change', e => { form.metodo = e.target.value; aggiorna(); }));
  document.querySelectorAll('input[name="f-statici"]').forEach(r => r.addEventListener('change', e => { form.statici = e.target.value; aggiorna(); }));
  document.querySelectorAll('input[name="f-tema"]').forEach(r => r.addEventListener('change', e => { form.tema = e.target.value; aggiorna(); }));
  document.querySelectorAll('input[name="f-errori"]').forEach(r => r.addEventListener('change', e => { form.errori = e.target.value; $('#f-ricompila').disabled = form.errori !== 'campo'; aggiorna(); }));
  $('#f-ricompila').addEventListener('change', e => { form.ricompila = e.target.checked; aggiorna(); });

  // ---------------------------------------------------------------- import
  $('#btn-importa').addEventListener('click', () => {
    const html = $('#importa-html').value;
    const ul = $('#importa-nodi');
    if (!html.trim()) { ul.innerHTML = '<li><span class="nodo-tag">Nodo</span><span>Area vuota: incolla prima il tuo index.html.</span></li>'; return; }
    const letto = P.leggiHtml(html, new DOMParser());
    ul.innerHTML = letto.nodi.map(n => `<li><span class="nodo-tag">Nodo</span><strong>${esc(n.titolo)}</strong><span>${esc(n.causa)} ${esc(n.soluzione)}</span></li>`).join('');
    if (!letto.campi.length) return;
    fotografa();
    const titolo = (new DOMParser().parseFromString(html, 'text/html').querySelector('title') || {}).textContent;
    form.titolo = (titolo || form.titolo).trim();
    form.azione = letto.azione; form.metodo = letto.metodo;
    form.campi = letto.campi.map(l => campo({ etichetta: l.etichetta, nome: l.nome, nomeManuale: true, tipo: l.tipo, opzioni: l.opzioni || '', righe: l.righe || '4', colonne: l.colonne || '40', presenza: l.tipo === 'caselle' ? 'facoltativo' : 'obbligatorio' }));
    tuttoDaCapo();
    avviso(`${letto.campi.length} campi importati${letto.nodi.length ? ', nodi già sciolti nel file generato' : ''}. Scegli i controlli.`, true);
    registro.querySelector('[data-scelta]').focus();
  });

  // ---------------------------------------------------------------- i file
  function spec() { return { titolo: form.titolo, azione: form.azione, metodo: form.metodo, statici: form.statici || 'pipe', tema: P.temaDi(form), errori: P.erroriDi(form), ricompila: form.ricompila !== false, bottone: form.bottone, reset: form.reset, porta: 3000, campi: form.campi }; }
  function cartella() { return (P.slug(form.titolo).replace(/_/g, '-') || 'form').slice(0, 40); }
  function file() {
    const s = spec();
    const campiOk = s.campi.map(c => c.errore && c.regola === 'regex' ? Object.assign({}, c, { regola: 'libero' }) : c);
    let server;
    try { server = P.generaServer(Object.assign({}, s, { campi: campiOk }), SERVER_TPL); }
    catch (e) { server = '// Nodo: server.js non generato (' + e.message + ').\n'; }
    return { 'index.html': P.generaHtml(s), 'server.js': server, 'pico.min.css': window.PICO_CSS };
  }

  let vista = 'anteprima', ultimoServerVisto = '', correnti = file();
  const schede = [...document.querySelectorAll('.schede [data-vista]')];
  function mostra() {
    const iframe = $('#anteprima'), box = $('#pettinatura'), perche = $('#perche');
    iframe.hidden = vista !== 'anteprima';
    box.hidden = !['index.html', 'server.js'].includes(vista);
    perche.hidden = vista !== 'perche';
    $('#btn-copia').hidden = vista === 'perche';
    if (vista === 'anteprima') {
      const html = correnti['index.html'].replace('<link rel="stylesheet" href="/pico.min.css">', '<style>' + window.PICO_CSS + '</style>');
      if (iframe.srcdoc !== html) iframe.srcdoc = html;
    } else if (vista === 'perche') {
      perche.innerHTML = P.spiegazioni(spec()).map((s, i) => `<li><span class="num">${i + 1}</span><div><strong>${esc(s.titolo)}</strong><p>${esc(s.testo)}</p></div></li>`).join('');
    } else {
      const testo = correnti[vista];
      $('#codice').innerHTML = righe(segmenti(testo, vista === 'index.html' ? RE_HTML : RE_JS, vista === 'index.html' ? mappaHtml : mappaJs));
      if (vista === 'server.js' && testo !== ultimoServerVisto) { ultimoServerVisto = testo; pettina(); }
    }
  }
  function scegliScheda(b) {
    schede.forEach(x => { const on = x === b; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1; });
    vista = b.dataset.vista;
    mostra();
  }
  schede.forEach(b => b.addEventListener('click', () => scegliScheda(b)));
  $('.schede').addEventListener('keydown', e => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key) || !e.target.matches('[data-vista]')) return;
    e.preventDefault();
    const i = schede.indexOf(e.target);
    const j = e.key === 'Home' ? 0 : e.key === 'End' ? schede.length - 1 : (i + (e.key === 'ArrowRight' ? 1 : schede.length - 1)) % schede.length;
    schede[j].focus(); scegliScheda(schede[j]);
  });
  $('#btn-copia').addEventListener('click', () => {
    const nome = vista === 'anteprima' ? 'index.html' : vista;
    copia(correnti[nome], nome);
  });

  function stato(n) {
    const el = $('#stato');
    if (!n) { el.outerHTML = '<span id="stato" class="stato" aria-live="polite"><span class="stato__linea" aria-hidden="true"></span>Liscio, nessun nodo</span>'; return; }
    el.outerHTML = `<button id="stato" type="button" class="stato" aria-live="polite"><span class="nodo-tag">${n}</span>${n === 1 ? 'nodo da sciogliere' : 'nodi da sciogliere'}</button>`;
    $('#stato').addEventListener('click', vaiAlPrimoNodo);
  }
  function vaiAlPrimoNodo() {
    const li = registro.querySelector('.ha-nodo');
    if (!li) { $('#btn-aggiungi').focus(); return; }
    li.scrollIntoView({ block: 'center', behavior: riduciMoto.matches ? 'auto' : 'smooth' });
    const c = form.campi.find(x => x.id === li.dataset.id);
    const k = !String(c.etichetta).trim() ? 'etichetta' : /Almeno uno/.test(c.errore) ? 'presenza' : /Pattern|Regex/.test(c.errore) ? 'pattern' : /opzion/.test(c.errore) ? 'opzioni' : /valori/.test(c.errore) ? 'valori' : /uguale/.test(c.errore) ? 'campo' : 'nome';
    (li.querySelector(`[data-k="${k}"]`) || li.querySelector('input')).focus();
  }

  const aggiorna = rimanda(() => {
    const n = controlla();
    correnti = file();
    stato(n);
    $('#zip-nome').textContent = cartella() + '.zip';
    mostra();
    salva();
  }, 120);
  function tuttoDaCapo() { chiudi(false); impostazioni(); disegnaRegistro(); aggiorna(); }

  // ---------------------------------------------------------------- lo zip
  function scarica() {
    const n = controlla();
    if (n) {
      avviso(form.campi.length ? (n === 1 ? 'C\'è un nodo da sciogliere prima dello zip.' : `Ci sono ${n} nodi da sciogliere prima dello zip.`) : 'Il form non ha campi: aggiungine almeno uno.');
      vaiAlPrimoNodo();
      return;
    }
    const dir = cartella(), f = file();
    const byte = window.creaZip(Object.keys(f).map(k => ({ nome: dir + '/' + k, testo: f[k] })));
    const url = URL.createObjectURL(new Blob([byte], { type: 'application/zip' }));
    const a = document.createElement('a');
    a.href = url; a.download = dir + '.zip';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    avviso(dir + '.zip scaricato. Estrai e lancia node server.js.');
  }
  $('#btn-zip').addEventListener('click', scarica);
  addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === 's') { e.preventDefault(); scarica(); }
  });

  // ---------------------------------------------------------------- la passata del pettine
  function pettina() {
    if (riduciMoto.matches) return;
    const box = $('#pettinatura'), scorre = $('#vista');
    scorre.scrollTop = 0;
    const alto = scorre.clientHeight, durata = 1000;
    box.querySelectorAll('.r').forEach(r => {
      const quota = Math.min(r.offsetTop / alto, 1);
      r.style.setProperty('--dx', (Math.random() * 28 - 14).toFixed(1) + 'px');
      r.style.setProperty('--dy', (Math.random() * 4 - 2).toFixed(1) + 'px');
      r.style.setProperty('--rot', (Math.random() * 2.4 - 1.2).toFixed(2) + 'deg');
      r.style.setProperty('--ritardo', Math.round(quota * durata * 0.92) + 'ms');
    });
    box.style.setProperty('--durata', durata + 'ms');
    box.style.setProperty('--corsa', (alto - 14) + 'px');
    box.classList.remove('passata'); box.classList.add('groviglio');
    void box.offsetWidth;
    box.classList.remove('groviglio'); box.classList.add('passata');
    clearTimeout(pettina.t);
    pettina.t = setTimeout(() => box.classList.remove('passata'), durata + 600);
  }

  // ---------------------------------------------------------------- avvio
  // la scorciatoia giusta per il sistema
  const kbd = document.querySelector('#btn-zip kbd');
  if (kbd && !/Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent)) kbd.textContent = 'Ctrl+S';
  tuttoDaCapo();
})();
