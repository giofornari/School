// Genera dist/tutti-i-tipi.zip: un campo per ogni tipo e per ogni controllo di testo,
// con lo stesso codice del tool. Uso: node tools/esempio-completo.mjs
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const radice = join(dirname(fileURLToPath(import.meta.url)), '..');
const P = require(join(radice, 'lib/genera.js'));
const { creaZip } = require(join(radice, 'lib/zip.js'));

const spec = P.esempioCompleto();
// stesso nome di cartella che usa il tool: il titolo in minuscolo con i trattini
const dir = P.slug(spec.titolo).replace(/_/g, '-').slice(0, 40);
const file = {
  'server.js': P.generaServer(spec, readFileSync(join(radice, 'lib/server.tpl.js'), 'utf8')),
  'index.html': P.generaHtml(spec),
  'pico.min.css': readFileSync(join(radice, 'vendor/pico.min.css'), 'utf8'),
};
mkdirSync(join(radice, 'dist'), { recursive: true });
writeFileSync(join(radice, 'dist', dir + '.zip'), creaZip(Object.keys(file).map(k => ({ nome: dir + '/' + k, testo: file[k] }))));
console.log(`dist/${dir}.zip: ${spec.campi.length} campi, server.js di ${file['server.js'].split('\n').length} righe`);
