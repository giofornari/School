const http = require("http");
const fs = require("fs");
const path = require("path");
const qs = require("querystring");

const hostname = "127.0.0.1";
const port = 3000;

const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css'
};

const allowedURLPaths = {
    '/': './index.html',
    '/pico.min.css': './pico.min.css'
};

const RE_LETTERE = /^[A-Za-zÀ-ÖØ-öø-ÿ' ]+$/;
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RE_CIFRE_5 = /^\d{5}$/;
const RE_TELEFONO = /^\+?\d{6,15}$/;
const RE_CAP = /^\d{5}$/;
const RE_CELLULARE = /^(\+39)?3\d{8,9}$/;
const RE_CF = /^[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]$/;
const RE_PIVA = /^\d{11}$/;
const RE_TARGA = /^[A-Z]{2}\d{3}[A-Z]{2}$/;
const RE_DATA = /^(\d{2})\/(\d{2})\/(\d{4})$/;
const RE_INTERO = /^-?\d+$/;
const RE_DECIMALE = /^-?\d+([.,]\d+)?$/;
const RE_PASSWORD = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
const RE_ALFANUMERICO = /^[A-Za-z0-9]+$/;
const RE_INIZIALE = /^[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ' ]*$/;
const RE_SOLO_CIFRE = /^\d+$/;
const VALORI_C19 = ["m", "f"];
const RE_ORA = /^([01]\d|2[0-3]):[0-5]\d$/;
const RE_URL = /^https?:\/\/[\w-]+(\.[\w-]+)+(\/\S*)?$/;
const RE_IBAN = /^IT\d{2}[A-Z]\d{10}[0-9A-Z]{12}$/;
const RE_PROVINCIA = /^[A-Z]{2}$/;
const RE_CIVICO = /^\d{1,4}(\s?[A-Za-z]|\/\d{1,3}|\s?bis|\s?ter)?$/i;
const RE_IPV4 = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
const RE_MAC = /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/;
const RE_USERNAME = /^[A-Za-z][A-Za-z0-9_]{2,15}$/;
const RE_PREZZO = /^\d+([.,]\d{1,2})?$/;
const RE_CAMPO_C31 = /^[a-z]+$/;

function dataValida(s) {
    if (!RE_DATA.test(s)) {
        return false;
    }
    const parti = s.split('/');
    const giorno = Number(parti[0]);
    const mese = Number(parti[1]);
    const anno = Number(parti[2]);
    const d = new Date(anno, mese - 1, giorno);
    return d.getFullYear() === anno && d.getMonth() === mese - 1 && d.getDate() === giorno;
}

function anniCompiuti(s) {
    const parti = s.split('/');
    const nascita = new Date(Number(parti[2]), Number(parti[1]) - 1, Number(parti[0]));
    const oggi = new Date();
    let anni = oggi.getFullYear() - nascita.getFullYear();
    if (oggi.getMonth() < nascita.getMonth()) {
        anni--;
    } else if (oggi.getMonth() === nascita.getMonth() && oggi.getDate() < nascita.getDate()) {
        anni--;
    }
    return anni;
}

function inviaFileStatico(res, pathname) {
    const filePath = allowedURLPaths[pathname];
    const contentType = mimeTypes[path.extname(filePath)];
    const fileStream = fs.createReadStream(filePath);

    fileStream.on('open', function () {
        res.writeHead(200, { 'Content-Type': contentType });
        fileStream.pipe(res);
    });

    fileStream.on('error', function (error) {
        console.error('Errore nella lettura del file: ' + error.message);
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('File non trovato');
    });
}

function validaDati(dati) {
    const valori = {};
    valori.c0 = String(dati.c0 || '').trim();
    valori.c1 = String(dati.c1 || '').trim();
    valori.c2 = String(dati.c2 || '').trim();
    valori["campo-3"] = String(dati["campo-3"] || '').trim();
    valori.c4 = String(dati.c4 || '').trim();
    valori.c5 = String(dati.c5 || '').trim();
    valori.c6 = String(dati.c6 || '').trim();
    valori.c7 = String(dati.c7 || '').trim();
    valori.c8 = String(dati.c8 || '').trim();
    valori.c9 = String(dati.c9 || '').trim();
    valori.c10 = String(dati.c10 || '').trim();
    valori.c11 = String(dati.c11 || '').trim();
    valori.c12 = String(dati.c12 || '').trim();
    valori.c13 = String(dati.c13 || '').trim();
    valori.c14 = String(dati.c14 || '').trim();
    valori.c15 = String(dati.c15 || '').trim();
    valori.c16 = String(dati.c16 || '').trim();
    valori.c17 = String(dati.c17 || '').trim();
    valori.c18 = String(dati.c18 || '').trim();
    valori.c19 = String(dati.c19 || '').trim();
    valori.c20 = String(dati.c20 || '').trim();
    valori.c21 = String(dati.c21 || '').trim();
    valori.c22 = String(dati.c22 || '').trim();
    valori.c23 = String(dati.c23 || '').trim();
    valori.c24 = String(dati.c24 || '').trim();
    valori.c25 = String(dati.c25 || '').trim();
    valori.c26 = String(dati.c26 || '').trim();
    valori.c27 = String(dati.c27 || '').trim();
    valori.c28 = String(dati.c28 || '').trim();
    valori.c29 = String(dati.c29 || '').trim();
    valori.c30 = String(dati.c30 || '').trim();
    valori.c31 = String(dati.c31 || '').trim();

    const errori = [];
    if (valori.c0 === '') {
        errori.push("Il campo «Campo 0» è obbligatorio.");
    }

    if (valori.c1 !== '' && !RE_LETTERE.test(valori.c1)) {
        errori.push("«Campo 1» può contenere solo lettere, spazi e apostrofi.");
    }

    if (valori.c2 !== '' && !RE_EMAIL.test(valori.c2)) {
        errori.push("«Campo 2» non è un indirizzo email valido (es. nome@dominio.it).");
    }

    if (valori["campo-3"] === '') {
        errori.push("Il campo «Campo 3» è obbligatorio.");
    } else if (!isNaN(valori["campo-3"])) {
        errori.push("«Campo 3» non può essere un numero.");
    }

    if (valori.c4 !== '' && !RE_CIFRE_5.test(valori.c4)) {
        errori.push("«Campo 4» deve essere un numero di 5 cifre.");
    }

    if (valori.c5 !== '' && !RE_TELEFONO.test(valori.c5.replace(/[\s.\/-]/g, ''))) {
        errori.push("«Campo 5» non è un numero di telefono valido.");
    }

    if (valori.c6 === '') {
        errori.push("Il campo «Campo 6» è obbligatorio.");
    } else if (!RE_CAP.test(valori.c6)) {
        errori.push("«Campo 6» deve essere di 5 cifre.");
    }

    if (valori.c7 !== '' && !RE_CELLULARE.test(valori.c7.replace(/\s/g, ''))) {
        errori.push("«Campo 7» non è un numero di cellulare valido (es. 347 1234567).");
    }

    if (valori.c8 !== '' && !RE_CF.test(valori.c8.toUpperCase())) {
        errori.push("«Campo 8» non è un codice fiscale valido.");
    }

    if (valori.c9 === '') {
        errori.push("Il campo «Campo 9» è obbligatorio.");
    } else if (!RE_PIVA.test(valori.c9)) {
        errori.push("«Campo 9» deve essere di 11 cifre.");
    }

    if (valori.c10 !== '' && !RE_TARGA.test(valori.c10.toUpperCase())) {
        errori.push("«Campo 10» non è una targa valida (es. AB123CD).");
    }

    if (valori.c11 !== '' && !dataValida(valori.c11)) {
        errori.push("«Campo 11» deve essere una data reale nel formato gg/mm/aaaa.");
    }

    if (valori.c12 === '') {
        errori.push("Il campo «Campo 12» è obbligatorio.");
    } else if (!RE_INTERO.test(valori.c12)) {
        errori.push("«Campo 12» deve essere un numero intero tra 1 e 9.");
    } else if (Number(valori.c12) < 1) {
        errori.push("«Campo 12» deve essere un numero intero tra 1 e 9.");
    } else if (Number(valori.c12) > 9) {
        errori.push("«Campo 12» deve essere un numero intero tra 1 e 9.");
    }

    if (valori.c13 !== '') {
        if (!RE_DECIMALE.test(valori.c13)) {
            errori.push("«Campo 13» deve essere un numero tra 1 e 9.");
        } else if (Number(valori.c13.replace(',', '.')) < 1) {
            errori.push("«Campo 13» deve essere un numero tra 1 e 9.");
        } else if (Number(valori.c13.replace(',', '.')) > 9) {
            errori.push("«Campo 13» deve essere un numero tra 1 e 9.");
        }
    }

    if (valori.c14 !== '') {
        if (valori.c14.length < 1) {
            errori.push("«Campo 14» deve avere tra 1 e 9 caratteri.");
        } else if (valori.c14.length > 9) {
            errori.push("«Campo 14» deve avere tra 1 e 9 caratteri.");
        }
    }

    if (valori.c15 === '') {
        errori.push("Il campo «Campo 15» è obbligatorio.");
    } else if (!RE_PASSWORD.test(valori.c15)) {
        errori.push("«Campo 15» deve avere almeno 8 caratteri, con una maiuscola, una minuscola e un numero.");
    }

    if (valori.c16 !== '' && !RE_ALFANUMERICO.test(valori.c16)) {
        errori.push("«Campo 16» può contenere solo lettere e cifre, senza spazi.");
    }

    if (valori.c17 !== '' && !RE_INIZIALE.test(valori.c17)) {
        errori.push("«Campo 17» deve iniziare con la maiuscola e contenere solo lettere.");
    }

    if (valori.c18 === '') {
        errori.push("Il campo «Campo 18» è obbligatorio.");
    } else if (!RE_SOLO_CIFRE.test(valori.c18)) {
        errori.push("«Campo 18» può contenere solo cifre.");
    }

    if (valori.c19 !== '' && !VALORI_C19.includes(valori.c19.toLowerCase())) {
        errori.push("«Campo 19» deve essere uno tra: M, F.");
    }

    if (valori.c20 !== '' && valori.c20 !== valori.c0) {
        errori.push("«Campo 20» deve essere uguale al campo «c0».");
    }

    if (valori.c21 === '') {
        errori.push("Il campo «Campo 21» è obbligatorio.");
    } else if (!dataValida(valori.c21)) {
        errori.push("«Campo 21» deve essere una data reale (gg/mm/aaaa) di chi ha almeno 18 anni.");
    } else if (anniCompiuti(valori.c21) < 18) {
        errori.push("«Campo 21» deve essere una data reale (gg/mm/aaaa) di chi ha almeno 18 anni.");
    }

    if (valori.c22 !== '' && !RE_ORA.test(valori.c22)) {
        errori.push("«Campo 22» deve essere un'ora nel formato hh:mm (es. 08:30).");
    }

    if (valori.c23 !== '' && !RE_URL.test(valori.c23)) {
        errori.push("«Campo 23» deve essere un indirizzo che inizia con http:// o https:// (es. https://www.sito.it).");
    }

    if (valori.c24 === '') {
        errori.push("Il campo «Campo 24» è obbligatorio.");
    } else if (!RE_IBAN.test(valori.c24.replace(/\s/g, '').toUpperCase())) {
        errori.push("«Campo 24» non è un IBAN italiano valido (27 caratteri, inizia con IT).");
    }

    if (valori.c25 !== '' && !RE_PROVINCIA.test(valori.c25.toUpperCase())) {
        errori.push("«Campo 25» deve essere una sigla di 2 lettere (es. PR).");
    }

    if (valori.c26 !== '' && !RE_CIVICO.test(valori.c26)) {
        errori.push("«Campo 26» non è un numero civico valido (es. 12, 12A, 12/3).");
    }

    if (valori.c27 === '') {
        errori.push("Il campo «Campo 27» è obbligatorio.");
    } else if (!RE_IPV4.test(valori.c27)) {
        errori.push("«Campo 27» non è un indirizzo IPv4 valido (es. 192.168.1.10).");
    }

    if (valori.c28 !== '' && !RE_MAC.test(valori.c28)) {
        errori.push("«Campo 28» non è un indirizzo MAC valido (es. 00:1A:2B:3C:4D:5E).");
    }

    if (valori.c29 !== '' && !RE_USERNAME.test(valori.c29)) {
        errori.push("«Campo 29» deve avere da 3 a 16 caratteri, iniziare con una lettera e contenere solo lettere, cifre e _.");
    }

    if (valori.c30 === '') {
        errori.push("Il campo «Campo 30» è obbligatorio.");
    } else if (!RE_PREZZO.test(valori.c30)) {
        errori.push("«Campo 30» deve essere un importo con al massimo 2 decimali (es. 12,50).");
    }

    if (valori.c31 !== '' && !RE_CAMPO_C31.test(valori.c31)) {
        errori.push("Formato non valido.");
    }

    if (valori.c2 === '' && valori.c5 === '' && valori.c8 === '' && valori.c11 === '' && valori.c14 === '' && valori.c17 === '' && valori.c20 === '' && valori.c23 === '' && valori.c26 === '' && valori.c29 === '') {
        errori.push("Compila almeno uno tra «Campo 2», «Campo 5», «Campo 8», «Campo 11», «Campo 14», «Campo 17», «Campo 20», «Campo 23», «Campo 26» e «Campo 29».");
    }
    return errori;
}

function paginaRisposta(titolo, contenuto) {
    return `<!DOCTYPE html>
<html lang="it" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${titolo}</title>
    <link rel="stylesheet" href="/pico.min.css">
</head>
<body>
    <main class="container">
        <h1>${titolo}</h1>
        ${contenuto}
        <p><a href="/">Torna al form</a></p>
    </main>
</body>
</html>`;
}

function rispondi(res, dati) {
    const errori = validaDati(dati);

    if (errori.length > 0) {
        let elenco = '';
        for (const errore of errori) {
            elenco += `<li>${errore}</li>`;
        }
        res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(paginaRisposta('Dati non validi', `<ul>${elenco}</ul>`));
        return;
    }

    let righe = '';
    for (const campo in dati) {
        righe += `<tr><th>${campo}</th><td>${dati[campo]}</td></tr>`;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(paginaRisposta('Dati ricevuti', `<table><tbody>${righe}</tbody></table>`));
}

function requestHandler(req, res) {
    console.log(req.method + ' ' + req.url);

    const oggettourl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = oggettourl.pathname;

    if (pathname === '/recuperadati' && req.method === 'POST') {
        let body = "";
        req.on('data', function (data) {
            body += data;
        });
        req.on('end', function () {
            const dati = qs.parse(body);
            rispondi(res, dati);
        });
    } else if (pathname === '/recuperadati') {
        const dati = qs.parse(oggettourl.search.slice(1));
        rispondi(res, dati);
    } else if (allowedURLPaths.hasOwnProperty(pathname)) {
        inviaFileStatico(res, pathname);
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Pagina non trovata');
    }
}

const server = http.createServer(requestHandler);
server.listen(port, hostname, function () {
    console.log(`Server running at http://${hostname}:${port}/`);
});
