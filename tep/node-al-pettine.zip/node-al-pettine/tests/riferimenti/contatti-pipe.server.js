const http = require("http");
const fs = require("fs");
const path = require("path");
const qs = require("querystring");

const hostname = "127.0.0.1";
const port = 3000;

const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css'
};

const allowedURLPaths = {
    '/': './index.html',
    '/pico.min.css': './pico.min.css'
};

const RE_CIFRE_5 = /^\d{5}$/;
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RE_TELEFONO = /^\+?\d{6,15}$/;
const RE_DATA = /^(\d{2})\/(\d{2})\/(\d{4})$/;

function dataValida(s) {
    if (!RE_DATA.test(s)) {
        return false;
    }
    const parti = s.split('/');
    const giorno = Number(parti[0]);
    const mese = Number(parti[1]);
    const anno = Number(parti[2]);
    const d = new Date(anno, mese - 1, giorno);
    return d.getFullYear() === anno && d.getMonth() === mese - 1 && d.getDate() === giorno;
}

function inviaFileStatico(res, pathname) {
    const filePath = allowedURLPaths[pathname];
    const contentType = mimeTypes[path.extname(filePath)];
    const fileStream = fs.createReadStream(filePath);

    fileStream.on('open', function () {
        res.writeHead(200, { 'Content-Type': contentType });
        fileStream.pipe(res);
    });

    fileStream.on('error', function (error) {
        console.error('Errore nella lettura del file: ' + error.message);
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('File non trovato');
    });
}

function validaDati(dati) {
    const valori = {};
    valori.cognome = String(dati.cognome || '').trim();
    valori.nome = String(dati.nome || '').trim();
    valori.matricola = String(dati.matricola || '').trim();
    valori.email = String(dati.email || '').trim();
    valori.telefono = String(dati.telefono || '').trim();
    valori.data_di_nascita = String(dati.data_di_nascita || '').trim();

    const errori = [];
    if (valori.cognome === '') {
        errori.push("Il campo «Cognome» è obbligatorio.");
    } else if (!isNaN(valori.cognome)) {
        errori.push("«Cognome» non può essere un numero.");
    }

    if (valori.nome === '') {
        errori.push("Il campo «Nome» è obbligatorio.");
    } else if (!isNaN(valori.nome)) {
        errori.push("«Nome» non può essere un numero.");
    }

    if (valori.matricola === '') {
        errori.push("Il campo «Matricola» è obbligatorio.");
    } else if (!RE_CIFRE_5.test(valori.matricola)) {
        errori.push("«Matricola» deve essere un numero di 5 cifre.");
    }

    if (valori.email !== '' && !RE_EMAIL.test(valori.email)) {
        errori.push("«Email» non è un indirizzo email valido (es. nome@dominio.it).");
    }

    if (valori.telefono !== '' && !RE_TELEFONO.test(valori.telefono.replace(/[\s.\/-]/g, ''))) {
        errori.push("«Telefono» non è un numero di telefono valido.");
    }

    if (valori.data_di_nascita !== '' && !dataValida(valori.data_di_nascita)) {
        errori.push("«Data di nascita» deve essere una data reale nel formato gg/mm/aaaa.");
    }

    if (valori.email === '' && valori.telefono === '') {
        errori.push("Compila almeno uno tra «Email» e «Telefono».");
    }
    return errori;
}

function paginaRisposta(titolo, contenuto) {
    return `<!DOCTYPE html>
<html lang="it" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${titolo}</title>
    <link rel="stylesheet" href="/pico.min.css">
</head>
<body>
    <main class="container">
        <h1>${titolo}</h1>
        ${contenuto}
        <p><a href="/">Torna al form</a></p>
    </main>
</body>
</html>`;
}

function rispondi(res, dati) {
    const errori = validaDati(dati);

    if (errori.length > 0) {
        let elenco = '';
        for (const errore of errori) {
            elenco += `<li>${errore}</li>`;
        }
        res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(paginaRisposta('Dati non validi', `<ul>${elenco}</ul>`));
        return;
    }

    let righe = '';
    for (const campo in dati) {
        righe += `<tr><th>${campo}</th><td>${dati[campo]}</td></tr>`;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(paginaRisposta('Dati ricevuti', `<table><tbody>${righe}</tbody></table>`));
}

function requestHandler(req, res) {
    console.log(req.method + ' ' + req.url);

    const oggettourl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = oggettourl.pathname;

    if (pathname === '/recuperadati' && req.method === 'POST') {
        let body = "";
        req.on('data', function (data) {
            body += data;
        });
        req.on('end', function () {
            const dati = qs.parse(body);
            rispondi(res, dati);
        });
    } else if (pathname === '/recuperadati') {
        const dati = qs.parse(oggettourl.search.slice(1));
        rispondi(res, dati);
    } else if (allowedURLPaths.hasOwnProperty(pathname)) {
        inviaFileStatico(res, pathname);
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Pagina non trovata');
    }
}

const server = http.createServer(requestHandler);
server.listen(port, hostname, function () {
    console.log(`Server running at http://${hostname}:${port}/`);
});
