const http = require("http");
const fs = require("fs");
const path = require("path");
const qs = require("querystring");

const hostname = "127.0.0.1";
const port = 3000;

const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css'
};

const allowedURLPaths = {
    '/': './index.html',
    '/pico.min.css': './pico.min.css'
};

const VALORI_REGIONE = [
    "Abruzzo", "Basilicata", "Calabria", "Campania", "Emilia-Romagna",
    "Friuli-Venezia Giulia", "Lazio", "Liguria", "Lombardia", "Marche",
    "Molise", "Piemonte", "Puglia", "Sardegna", "Sicilia", "Toscana",
    "Trentino-Alto Adige", "Umbria", "Valle d'Aosta", "Veneto"
];
const VALORI_PROVINCIA = [
    "AG", "AL", "AN", "AO", "AP", "AQ", "AR", "AT", "AV", "BA", "BG", "BI",
    "BL", "BN", "BO", "BR", "BS", "BT", "BZ", "CA", "CB", "CE", "CH", "CL",
    "CN", "CO", "CR", "CS", "CT", "CZ", "EN", "FC", "FE", "FG", "FI", "FM",
    "FR", "GE", "GO", "GR", "IM", "IS", "KR", "LC", "LE", "LI", "LO", "LT",
    "LU", "MB", "MC", "ME", "MI", "MN", "MO", "MS", "MT", "NA", "NO", "NU",
    "OR", "PA", "PC", "PD", "PE", "PG", "PI", "PN", "PO", "PR", "PT", "PU",
    "PV", "PZ", "RA", "RC", "RE", "RG", "RI", "RM", "RN", "RO", "SA", "SI",
    "SO", "SP", "SR", "SS", "SU", "SV", "TA", "TE", "TN", "TO", "TP", "TR",
    "TS", "TV", "UD", "VA", "VB", "VC", "VE", "VI", "VR", "VT", "VV"
];
const VALORI_SESSO = [
    "M", "F"
];
const VALORI_STATO_CIVILE = [
    "celibe/nubile", "coniugato/a", "vedovo/a", "divorziato/a"
];
const VALORI_HOBBY = [
    "calcio", "musica", "lettura", "videogiochi"
];
const VALORI_LINGUAGGI = [
    "html", "css", "js", "node"
];

const RE_LETTERE = /^[A-Za-zÀ-ÖØ-öø-ÿ' ]+$/;
const RE_INIZIALE = /^[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ' ]*$/;
const RE_CIFRE_5 = /^\d{5}$/;
const RE_SOLO_CIFRE = /^\d+$/;
const RE_ALFANUMERICO = /^[A-Za-z0-9]+$/;
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RE_TELEFONO = /^\+?\d{6,15}$/;
const RE_CELLULARE = /^(\+39)?3\d{8,9}$/;
const RE_CAP = /^\d{5}$/;
const RE_PROVINCIA = /^[A-Z]{2}$/;
const RE_CIVICO = /^\d{1,4}(\s?[A-Za-z]|\/\d{1,3}|\s?bis|\s?ter)?$/i;
const RE_DATA = /^(\d{2})\/(\d{2})\/(\d{4})$/;
const RE_ORA = /^([01]\d|2[0-3]):[0-5]\d$/;
const RE_INTERO = /^-?\d+$/;
const RE_DECIMALE = /^-?\d+([.,]\d+)?$/;
const RE_PREZZO = /^\d+([.,]\d{1,2})?$/;
const VALORI_TURNO = ["mattina", "pomeriggio"];
const RE_USERNAME = /^[A-Za-z][A-Za-z0-9_]{2,15}$/;
const RE_PASSWORD = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
const RE_CF = /^[A-Z]{6}\d{2}[A-EHLMPRST]\d{2}[A-Z]\d{3}[A-Z]$/;
const RE_PIVA = /^\d{11}$/;
const RE_IBAN = /^IT\d{2}[A-Z]\d{10}[0-9A-Z]{12}$/;
const RE_TARGA = /^[A-Z]{2}\d{3}[A-Z]{2}$/;
const RE_URL = /^https?:\/\/[\w-]+(\.[\w-]+)+(\/\S*)?$/;
const RE_IPV4 = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
const RE_MAC = /^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/;
const RE_CAMPO_CORSO = /^[A-Z]{3}-\d{2}$/;

function dataValida(s) {
    if (!RE_DATA.test(s)) {
        return false;
    }
    const parti = s.split('/');
    const giorno = Number(parti[0]);
    const mese = Number(parti[1]);
    const anno = Number(parti[2]);
    const d = new Date(anno, mese - 1, giorno);
    return d.getFullYear() === anno && d.getMonth() === mese - 1 && d.getDate() === giorno;
}

function anniCompiuti(s) {
    const parti = s.split('/');
    const nascita = new Date(Number(parti[2]), Number(parti[1]) - 1, Number(parti[0]));
    const oggi = new Date();
    let anni = oggi.getFullYear() - nascita.getFullYear();
    if (oggi.getMonth() < nascita.getMonth()) {
        anni--;
    } else if (oggi.getMonth() === nascita.getMonth() && oggi.getDate() < nascita.getDate()) {
        anni--;
    }
    return anni;
}

function inviaFileStatico(res, pathname) {
    const filePath = allowedURLPaths[pathname];
    const contentType = mimeTypes[path.extname(filePath)];

    fs.readFile(filePath, function (error, data) {
        if (error) {
            console.error('Errore nella lettura del file: ' + error.message);
            res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('File non trovato');
            return;
        }
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
}

function validaDati(dati) {
    const valori = {};
    valori.cognome = String(dati.cognome || '').trim();
    valori.nome = String(dati.nome || '').trim();
    valori.soprannome = String(dati.soprannome || '').trim();
    valori.citta = String(dati.citta || '').trim();
    valori.matricola = String(dati.matricola || '').trim();
    valori.tessera = String(dati.tessera || '').trim();
    valori.badge = String(dati.badge || '').trim();
    valori.email = String(dati.email || '').trim();
    valori.conferma_email = String(dati.conferma_email || '').trim();
    valori.telefono = String(dati.telefono || '').trim();
    valori.cellulare = String(dati.cellulare || '').trim();
    valori.cap = String(dati.cap || '').trim();
    valori.sigla = String(dati.sigla || '').trim();
    valori.civico = String(dati.civico || '').trim();
    valori.iscrizione = String(dati.iscrizione || '').trim();
    valori.nascita = String(dati.nascita || '').trim();
    valori.ora = String(dati.ora || '').trim();
    valori.eta = String(dati.eta || '').trim();
    valori.altezza = String(dati.altezza || '').trim();
    valori.quota = String(dati.quota || '').trim();
    valori.motto = String(dati.motto || '').trim();
    valori.turno = String(dati.turno || '').trim();
    valori.username = String(dati.username || '').trim();
    valori.password = String(dati.password || '').trim();
    valori.cf = String(dati.cf || '').trim();
    valori.piva = String(dati.piva || '').trim();
    valori.iban = String(dati.iban || '').trim();
    valori.targa = String(dati.targa || '').trim();
    valori.sito = String(dati.sito || '').trim();
    valori.ip = String(dati.ip || '').trim();
    valori.mac = String(dati.mac || '').trim();
    valori.corso = String(dati.corso || '').trim();
    valori.regione = String(dati.regione || '').trim();
    valori.provincia = String(dati.provincia || '').trim();
    valori.sesso = String(dati.sesso || '').trim();
    valori.stato_civile = String(dati.stato_civile || '').trim();
    valori.hobby = dati.hobby || [];
    if (typeof valori.hobby === 'string') {
        valori.hobby = [valori.hobby];
    }
    valori.linguaggi = dati.linguaggi || [];
    if (typeof valori.linguaggi === 'string') {
        valori.linguaggi = [valori.linguaggi];
    }
    valori.richieste = String(dati.richieste || '').trim();
    valori.regolamento = String(dati.regolamento || '').trim();

    const errori = [];
    if (valori.cognome === '') {
        errori.push("Il campo «Cognome» è obbligatorio.");
    } else if (!isNaN(valori.cognome)) {
        errori.push("«Cognome» non può essere un numero.");
    }

    if (valori.nome === '') {
        errori.push("Il campo «Nome» è obbligatorio.");
    } else if (!RE_LETTERE.test(valori.nome)) {
        errori.push("«Nome» può contenere solo lettere, spazi e apostrofi.");
    }

    if (valori.citta === '') {
        errori.push("Il campo «Città di nascita» è obbligatorio.");
    } else if (!RE_INIZIALE.test(valori.citta)) {
        errori.push("«Città di nascita» deve iniziare con la maiuscola e contenere solo lettere.");
    }

    if (valori.matricola === '') {
        errori.push("Il campo «Matricola» è obbligatorio.");
    } else if (!RE_CIFRE_5.test(valori.matricola)) {
        errori.push("«Matricola» deve essere un numero di 5 cifre.");
    }

    if (valori.tessera === '') {
        errori.push("Il campo «Numero tessera» è obbligatorio.");
    } else if (!RE_SOLO_CIFRE.test(valori.tessera)) {
        errori.push("«Numero tessera» può contenere solo cifre.");
    }

    if (valori.badge === '') {
        errori.push("Il campo «Codice badge» è obbligatorio.");
    } else if (!RE_ALFANUMERICO.test(valori.badge)) {
        errori.push("«Codice badge» può contenere solo lettere e cifre, senza spazi.");
    }

    if (valori.email !== '' && !RE_EMAIL.test(valori.email)) {
        errori.push("«Email» non è un indirizzo email valido (es. nome@dominio.it).");
    }

    if (valori.conferma_email !== '' && valori.conferma_email !== valori.email) {
        errori.push("«Conferma email» deve essere uguale al campo «email».");
    }

    if (valori.telefono !== '' && !RE_TELEFONO.test(valori.telefono.replace(/[\s.\/-]/g, ''))) {
        errori.push("«Telefono fisso» non è un numero di telefono valido.");
    }

    if (valori.cellulare !== '' && !RE_CELLULARE.test(valori.cellulare.replace(/\s/g, ''))) {
        errori.push("«Cellulare» non è un numero di cellulare valido (es. 347 1234567).");
    }

    if (valori.cap === '') {
        errori.push("Il campo «CAP» è obbligatorio.");
    } else if (!RE_CAP.test(valori.cap)) {
        errori.push("«CAP» deve essere di 5 cifre.");
    }

    if (valori.sigla === '') {
        errori.push("Il campo «Sigla provincia» è obbligatorio.");
    } else if (!RE_PROVINCIA.test(valori.sigla.toUpperCase())) {
        errori.push("«Sigla provincia» deve essere una sigla di 2 lettere (es. PR).");
    }

    if (valori.civico === '') {
        errori.push("Il campo «Numero civico» è obbligatorio.");
    } else if (!RE_CIVICO.test(valori.civico)) {
        errori.push("«Numero civico» non è un numero civico valido (es. 12, 12A, 12/3).");
    }

    if (valori.iscrizione === '') {
        errori.push("Il campo «Data di iscrizione» è obbligatorio.");
    } else if (!dataValida(valori.iscrizione)) {
        errori.push("«Data di iscrizione» deve essere una data reale nel formato gg/mm/aaaa.");
    }

    if (valori.nascita === '') {
        errori.push("Il campo «Data di nascita» è obbligatorio.");
    } else if (!dataValida(valori.nascita)) {
        errori.push("«Data di nascita» deve essere una data reale (gg/mm/aaaa) di chi ha almeno 18 anni.");
    } else if (anniCompiuti(valori.nascita) < 18) {
        errori.push("«Data di nascita» deve essere una data reale (gg/mm/aaaa) di chi ha almeno 18 anni.");
    }

    if (valori.ora === '') {
        errori.push("Il campo «Ora di arrivo» è obbligatorio.");
    } else if (!RE_ORA.test(valori.ora)) {
        errori.push("«Ora di arrivo» deve essere un'ora nel formato hh:mm (es. 08:30).");
    }

    if (valori.eta === '') {
        errori.push("Il campo «Età» è obbligatorio.");
    } else if (!RE_INTERO.test(valori.eta)) {
        errori.push("«Età» deve essere un numero intero tra 14 e 99.");
    } else if (Number(valori.eta) < 14) {
        errori.push("«Età» deve essere un numero intero tra 14 e 99.");
    } else if (Number(valori.eta) > 99) {
        errori.push("«Età» deve essere un numero intero tra 14 e 99.");
    }

    if (valori.altezza !== '') {
        if (!RE_DECIMALE.test(valori.altezza)) {
            errori.push("«Altezza in metri» deve essere un numero tra 0.5 e 2.5.");
        } else if (Number(valori.altezza.replace(',', '.')) < 0.5) {
            errori.push("«Altezza in metri» deve essere un numero tra 0.5 e 2.5.");
        } else if (Number(valori.altezza.replace(',', '.')) > 2.5) {
            errori.push("«Altezza in metri» deve essere un numero tra 0.5 e 2.5.");
        }
    }

    if (valori.quota === '') {
        errori.push("Il campo «Quota versata» è obbligatorio.");
    } else if (!RE_PREZZO.test(valori.quota)) {
        errori.push("«Quota versata» deve essere un importo con al massimo 2 decimali (es. 12,50).");
    }

    if (valori.motto !== '') {
        if (valori.motto.length < 3) {
            errori.push("«Motto» deve avere tra 3 e 30 caratteri.");
        } else if (valori.motto.length > 30) {
            errori.push("«Motto» deve avere tra 3 e 30 caratteri.");
        }
    }

    if (valori.turno === '') {
        errori.push("Il campo «Turno» è obbligatorio.");
    } else if (!VALORI_TURNO.includes(valori.turno.toLowerCase())) {
        errori.push("«Turno» deve essere uno tra: mattina, pomeriggio.");
    }

    if (valori.username === '') {
        errori.push("Il campo «Username» è obbligatorio.");
    } else if (!RE_USERNAME.test(valori.username)) {
        errori.push("«Username» deve avere da 3 a 16 caratteri, iniziare con una lettera e contenere solo lettere, cifre e _.");
    }

    if (valori.password === '') {
        errori.push("Il campo «Password» è obbligatorio.");
    } else if (!RE_PASSWORD.test(valori.password)) {
        errori.push("«Password» deve avere almeno 8 caratteri, con una maiuscola, una minuscola e un numero.");
    }

    if (valori.cf === '') {
        errori.push("Il campo «Codice fiscale» è obbligatorio.");
    } else if (!RE_CF.test(valori.cf.toUpperCase())) {
        errori.push("«Codice fiscale» non è un codice fiscale valido.");
    }

    if (valori.piva !== '' && !RE_PIVA.test(valori.piva)) {
        errori.push("«Partita IVA» deve essere di 11 cifre.");
    }

    if (valori.iban !== '' && !RE_IBAN.test(valori.iban.replace(/\s/g, '').toUpperCase())) {
        errori.push("«IBAN» non è un IBAN italiano valido (27 caratteri, inizia con IT).");
    }

    if (valori.targa !== '' && !RE_TARGA.test(valori.targa.toUpperCase())) {
        errori.push("«Targa» non è una targa valida (es. AB123CD).");
    }

    if (valori.sito !== '' && !RE_URL.test(valori.sito)) {
        errori.push("«Sito web» deve essere un indirizzo che inizia con http:// o https:// (es. https://www.sito.it).");
    }

    if (valori.ip === '') {
        errori.push("Il campo «Indirizzo IP» è obbligatorio.");
    } else if (!RE_IPV4.test(valori.ip)) {
        errori.push("«Indirizzo IP» non è un indirizzo IPv4 valido (es. 192.168.1.10).");
    }

    if (valori.mac !== '' && !RE_MAC.test(valori.mac)) {
        errori.push("«Indirizzo MAC» non è un indirizzo MAC valido (es. 00:1A:2B:3C:4D:5E).");
    }

    if (valori.corso === '') {
        errori.push("Il campo «Codice corso» è obbligatorio.");
    } else if (!RE_CAMPO_CORSO.test(valori.corso)) {
        errori.push("Codice corso: tre lettere maiuscole, un trattino e due cifre (es. TDP-05).");
    }

    if (valori.regione === '') {
        errori.push("Scegli un valore per «Regione di residenza».");
    } else if (!VALORI_REGIONE.includes(valori.regione)) {
        errori.push("«Regione di residenza»: valore non ammesso.");
    }

    if (valori.provincia === '') {
        errori.push("Scegli un valore per «Provincia di residenza».");
    } else if (!VALORI_PROVINCIA.includes(valori.provincia)) {
        errori.push("«Provincia di residenza»: valore non ammesso.");
    }

    if (valori.sesso === '') {
        errori.push("Scegli un valore per «Sesso».");
    } else if (!VALORI_SESSO.includes(valori.sesso)) {
        errori.push("«Sesso»: valore non ammesso.");
    }

    if (valori.stato_civile !== '' && !VALORI_STATO_CIVILE.includes(valori.stato_civile)) {
        errori.push("«Stato civile»: valore non ammesso.");
    }

    if (valori.hobby.length === 0) {
        errori.push("Scegli almeno un'opzione in «Hobby».");
    } else if (valori.hobby.length > 3) {
        errori.push("Scegli al massimo 3 opzioni in «Hobby».");
    }
    for (const voce of valori.hobby) {
        if (!VALORI_HOBBY.includes(voce)) {
            errori.push("«Hobby»: c'è un valore non ammesso.");
            break;
        }
    }

    if (valori.linguaggi.length > 3) {
        errori.push("Scegli al massimo 3 opzioni in «Linguaggi conosciuti».");
    }
    for (const voce of valori.linguaggi) {
        if (!VALORI_LINGUAGGI.includes(voce)) {
            errori.push("«Linguaggi conosciuti»: c'è un valore non ammesso.");
            break;
        }
    }

    if (valori.richieste !== '' && valori.richieste.length > 500) {
        errori.push("«Richieste particolari» deve avere al massimo 500 caratteri.");
    }

    if (valori.regolamento !== 'si') {
        errori.push("Spunta la casella «Accetto il regolamento».");
    }

    if (valori.email === '' && valori.telefono === '' && valori.cellulare === '') {
        errori.push("Compila almeno uno tra «Email», «Telefono fisso» e «Cellulare».");
    }
    return errori;
}

function paginaRisposta(titolo, contenuto) {
    return `<!DOCTYPE html>
<html lang="it" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${titolo}</title>
    <link rel="stylesheet" href="/pico.min.css">
</head>
<body>
    <main class="container">
        <h1>${titolo}</h1>
        ${contenuto}
        <p><a href="/">Torna al form</a></p>
    </main>
</body>
</html>`;
}

function rispondi(res, dati) {
    const errori = validaDati(dati);

    if (errori.length > 0) {
        let elenco = '';
        for (const errore of errori) {
            elenco += `<li>${errore}</li>`;
        }
        res.writeHead(400, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(paginaRisposta('Dati non validi', `<ul>${elenco}</ul>`));
        return;
    }

    let righe = '';
    for (const campo in dati) {
        righe += `<tr><th>${campo}</th><td>${dati[campo]}</td></tr>`;
    }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(paginaRisposta('Dati ricevuti', `<table><tbody>${righe}</tbody></table>`));
}

function requestHandler(req, res) {
    console.log(req.method + ' ' + req.url);

    const oggettourl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = oggettourl.pathname;

    if (pathname === '/recuperadati' && req.method === 'POST') {
        let body = "";
        req.on('data', function (data) {
            body += data;
        });
        req.on('end', function () {
            const dati = qs.parse(body);
            rispondi(res, dati);
        });
    } else if (pathname === '/recuperadati') {
        const dati = qs.parse(oggettourl.search.slice(1));
        rispondi(res, dati);
    } else if (allowedURLPaths.hasOwnProperty(pathname)) {
        inviaFileStatico(res, pathname);
    } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('Pagina non trovata');
    }
}

const server = http.createServer(requestHandler);
server.listen(port, hostname, function () {
    console.log(`Server running at http://${hostname}:${port}/`);
});
