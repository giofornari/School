// Prove dei generatori: regex dei preset, zip, server generato avviato davvero.
// Uso: node tests/genera.test.mjs
import { createRequire } from 'node:module';
import { readFileSync, mkdtempSync, writeFileSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';

const require = createRequire(import.meta.url);
const radice = join(dirname(fileURLToPath(import.meta.url)), '..');
const P = require(join(radice, 'lib/genera.js'));
const { creaZip } = require(join(radice, 'lib/zip.js'));
const MODELLO = readFileSync(join(radice, 'lib/server.tpl.js'), 'utf8');

let ko = 0;
function ok(cond, msg) {
  if (cond) console.log('  ok  ' + msg);
  else { ko++; console.log('  KO  ' + msg); }
}

// ---------------------------------------------------------------- regex preset
console.log('Regex dei preset');
const casi = {
  lettere: [["Niccolò", "D'Amico", 'Anna Maria'], ['Mario3', 'a_b', '']],
  email: [['nome@dominio.it', 'a.b@c.com'], ['nome@dominio', 'a@@b.it', 'a b@c.it', '@c.it']],
  cap: [['43100', '00118'], ['4310', '431000', '43a00']],
  telefono: [['3471234567', '+393471234567', '347123456'], ['0521123456', '347', '+44347123456']],
  cf: [['RSSMRA85T10A562S', 'BNCLRA90A41H501Y'], ['RSSMRA85T10A562', 'RSSMRA85Z10A562S', '1234567890123456']],
  piva: [['01234567890'], ['0123456789', '0123456789a']],
  targa: [['AB123CD'], ['AB12CD', 'A1123CD']],
  password: [['Password1', 'aB3defgh'], ['password1', 'PASSWORD1', 'Pass1', 'Password']],
  alfanumerico: [['abc123', 'ABC'], ['abc 123', 'abc-1', '']],
  maiuscola: [['Rossi', 'De Luca', "D'Amico", 'Èlia'], ['rossi', 'Rossi3', '']],
  soloCifre: [['00123', '7'], ['12a', '1.5', '']],
  ora: [['00:00', '08:30', '23:59'], ['24:00', '8:30', '12:60', '1230']],
  url: [['https://www.sito.it', 'http://a.b/c?x=1'], ['www.sito.it', 'https://sito', 'ftp://a.b', 'https://a b.it']],
  iban: [['IT60X0542811101000000123456', 'it60 x054 2811 1010 0000 0123 456'], ['IT60X054281110100000012345', 'DE89370400440532013000']],
  provincia: [['PR', 'mi'], ['P', 'PRM', 'P1']],
  civico: [['12', '12A', '12/3', '12 bis', '1234'], ['A12', '12345', '12//3', '']],
  ipv4: [['192.168.1.10', '0.0.0.0', '255.255.255.255'], ['256.1.1.1', '192.168.1', '1.2.3.4.5', '01.2.3.4a']],
  mac: [['00:1A:2B:3C:4D:5E', '00-1a-2b-3c-4d-5e'], ['00:1A:2B:3C:4D', '00:1G:2B:3C:4D:5E']],
  username: [['mario_99', 'abc'], ['ab', '9mario', 'mario rossi', 'a'.repeat(17)]],
  prezzo: [['12', '12,50', '0.5'], ['12,505', '-3', '12,', '']],
};
for (const [id, [buoni, cattivi]] of Object.entries(casi)) {
  const re = eval(P.REGOLE[id].regex);
  const norm = s => ['cf', 'targa', 'provincia'].includes(id) ? s.toUpperCase() : id === 'telefono' ? s.replace(/\s/g, '') : id === 'iban' ? s.replace(/\s/g, '').toUpperCase() : s;
  ok(buoni.every(s => re.test(norm(s))), `${id}: validi passano`);
  ok(cattivi.every(s => !re.test(norm(s))), `${id}: non validi bloccati`);
}
ok(P.letteraleRegex('[A-Z]{3}/\\d+') === '/^[A-Z]{3}\\/\\d+$/', 'regex personalizzata: ^ $ e / protette');
let rotta = false; try { P.letteraleRegex('([a-z'); } catch { rotta = true; }
ok(rotta, 'regex personalizzata rotta: errore');

const normalizza = { cf: v => v.toUpperCase(), targa: v => v.toUpperCase(), provincia: v => v.toUpperCase(), telefono: v => v.replace(/\s/g, ''), iban: v => v.replace(/\s/g, '').toUpperCase() };
for (const id of ['provincia', 'iban']) {
  const re = eval(P.REGOLE[id].regex), [buoni, cattivi] = casi[id];
  ok(buoni.every(v => re.test(normalizza[id](v))) && cattivi.every(v => !re.test(normalizza[id](v))), `${id}: con normalizzazione`);
}

// Un server con TUTTE le regole, una per campo: deve essere JavaScript valido.
console.log('Tutte le regole insieme');
const tutte = Object.keys(P.REGOLE).map((r, i) => ({ etichetta: 'Campo ' + i, nome: 'c' + i, regola: r, presenza: 'facoltativo', min: '1', max: '9', cifre: '5', anni: '18', valori: 'M, F', campo: 'c0', pattern: '[a-z]+' }));
const serverTutte = P.generaServer({ titolo: 'T', azione: '/recuperadati', metodo: 'post', campi: tutte }, MODELLO);
const dirTutte = mkdtempSync(join(tmpdir(), 'pettine-tutte-'));
writeFileSync(join(dirTutte, 'server.js'), serverTutte);
let sintassi = true; try { execFileSync('node', ['--check', join(dirTutte, 'server.js')]); } catch { sintassi = false; }
ok(sintassi, `server con tutte le ${tutte.length} regole: sintassi valida`);

// Nessun commento nel codice generato: tutte le regole, tutti i tipi, tutti i modi dei file statici.
console.log('Nessun commento');
const senzaCommento = codice => !/^\s*\/\//m.test(codice) && !/\/\*/.test(codice) && !/;\s+\/\/ /.test(codice);
ok(senzaCommento(serverTutte), 'server con tutte le regole: nessun commento');
const completo = P.esempioCompleto();
for (const modo of ['pipe', 'eventi', 'readfile']) {
  const srv = P.generaServer(Object.assign({}, completo, { statici: modo }), MODELLO);
  ok(senzaCommento(srv), `esempio completo, ${modo}: nessun commento`);
  ok(srv.includes('http://${req.headers.host}') && srv.includes('Server running at http://'), `esempio completo, ${modo}: le stringhe con http:// sono intatte`);
}

// Istruzioni basiche: niente catene di metodi, frecce, switch o escape nel codice generato.
console.log('Stile del codice generato');
const vietati = ['escapeHtml', '??', '[].concat', '.map(', '.filter(', '.some(', '.forEach(', '=>', 'switch', 'hasOwnProperty(pathname) &&', '...'];
for (const modo of ['pipe', 'eventi', 'readfile']) {
  const srv = P.generaServer(Object.assign({}, completo, { statici: modo }), MODELLO);
  const trovati = vietati.filter(v => srv.includes(v));
  ok(trovati.length === 0, `esempio completo, ${modo}: nessun costrutto avanzato${trovati.length ? ' (trovati: ' + trovati.join(' ') + ')' : ''}`);
  const lunghe = srv.split('\n').filter(r => r.length > 100 && !/const RE_|errori\.push\(/.test(r));
  ok(lunghe.length === 0, `esempio completo, ${modo}: nessuna riga oltre 100 caratteri${lunghe.length ? '\n' + lunghe.join('\n') : ''}`);
}

// ---------------------------------------------------------------- zip + server
// Il form dell'esercizio della slide 54, più data, intero e regex personalizzata.
const spec = {
  titolo: 'Contatti', azione: '/recuperadati', metodo: 'post', porta: 3000, bottone: 'Invia', reset: true,
  campi: [
    { etichetta: 'Cognome', nome: 'cognome', regola: 'nonnumerico', presenza: 'obbligatorio' },
    { etichetta: 'Nome', nome: 'nome', regola: 'nonnumerico', presenza: 'obbligatorio' },
    { etichetta: 'Matricola', nome: 'matricola', regola: 'cifre', cifre: '5', presenza: 'obbligatorio' },
    { etichetta: 'Email', nome: 'email', regola: 'email', presenza: 'gruppo' },
    { etichetta: 'Telefono', nome: 'telefono', regola: 'telefonoGen', presenza: 'gruppo' },
    { etichetta: "L'età", nome: 'eta', regola: 'intero', presenza: 'facoltativo', min: '14', max: '19' },
    { etichetta: 'Data di nascita', nome: 'data-nascita', regola: 'data', presenza: 'facoltativo' },
    { etichetta: 'Codice corso', nome: 'corso', regola: 'regex', presenza: 'facoltativo', pattern: '[A-Z]{3}-\\d{2}', messaggio: 'Codice corso: tre maiuscole, trattino, due cifre (es. TDP-05).' },
    { etichetta: 'Sesso', nome: 'sesso', regola: 'elenco', presenza: 'facoltativo', valori: 'M, F' },
    { etichetta: 'Conferma email', nome: 'conferma', regola: 'uguale', presenza: 'facoltativo', campo: 'email' },
    { etichetta: 'Nascita tutore', nome: 'tutore', regola: 'maggiorenne', presenza: 'facoltativo', anni: '18' },
  ],
};
const html = P.generaHtml(spec);
ok(!/required|pattern=|maxlength|<input type="(?!text|submit|reset)/.test(html), 'HTML: solo type="text", nessuna validazione client');
ok(/<html lang="it" data-theme="light">/.test(html) && /data-theme="dark"/.test(P.generaHtml(Object.assign({}, spec, { tema: 'dark' }))), 'HTML: tema Pico chiaro di default, scuro a richiesta');
ok(/data-theme="dark"/.test(P.generaServer(Object.assign({}, spec, { tema: 'dark' }), MODELLO)), 'server: la pagina di risposta usa lo stesso tema');
ok(!/size=/.test(html) && /type="reset"/.test(html) && /action="\/recuperadati"/.test(html), 'HTML: niente size, reset, action /recuperadati');
let server = P.generaServer(spec, MODELLO);
ok(!/readFileSync\s*\(/.test(server) && /createReadStream/.test(server), 'server: stream, niente readFileSync');
ok(!/@@/.test(server), 'server: segnaposto tutti sostituiti');
ok(/function requestHandler\(req, res\)/.test(server) && /allowedURLPaths/.test(server) && /qs\.parse\(body\)/.test(server), 'server: lessico del prof (requestHandler, allowedURLPaths, qs.parse)');
const PORTA = 3900 + Math.floor(Math.random() * 90);
server = server.replace(/const port = \d+;/, `const port = ${PORTA};`);

const pico = readFileSync(join(radice, 'vendor/pico.min.css'), 'utf8');
const zip = creaZip([
  { nome: 'contatti/server.js', testo: server },
  { nome: 'contatti/index.html', testo: html },
  { nome: 'contatti/pico.min.css', testo: pico },
]);
const cartella = mkdtempSync(join(tmpdir(), 'pettine-'));
writeFileSync(join(cartella, 'prova.zip'), zip);
const test = execFileSync('unzip', ['-t', join(cartella, 'prova.zip')]).toString();
ok(/No errors detected/.test(test), 'zip: unzip -t senza errori');
execFileSync('unzip', ['-q', join(cartella, 'prova.zip'), '-d', cartella]);
ok(existsSync(join(cartella, 'contatti/pico.min.css')), 'zip: struttura estratta');
execFileSync('node', ['--check', join(cartella, 'contatti/server.js')]);
ok(true, 'server.js: sintassi valida');

const proc = spawn('node', ['server.js'], { cwd: join(cartella, 'contatti') });
await new Promise((ris, rif) => {
  proc.stdout.on('data', d => /running/.test(d) && ris());
  proc.stderr.on('data', d => rif(new Error(d.toString())));
  setTimeout(() => rif(new Error('timeout avvio')), 4000);
});
const base = `http://127.0.0.1:${PORTA}`;
const form = { 'Content-Type': 'application/x-www-form-urlencoded' };
const buono = new URLSearchParams({ cognome: "D'Amico", nome: 'Niccolò', matricola: '12345', email: '', telefono: '0521 123456', eta: '17', 'data-nascita': '29/02/2008', corso: 'TDP-05' });
const cattivo = new URLSearchParams({ cognome: '123', nome: '', matricola: '1234', email: 'x', telefono: '', eta: '30', 'data-nascita': '31/02/2008', corso: 'tdp5' });
const nessunContatto = new URLSearchParams({ cognome: 'Rossi', nome: 'Anna', matricola: '54321', email: '', telefono: '' });

try {
  let r = await fetch(base + '/');
  ok(r.status === 200 && /text\/html/.test(r.headers.get('content-type')), 'GET / → index.html 200 text/html');
  r = await fetch(base + '/pico.min.css');
  ok(r.status === 200 && /text\/css/.test(r.headers.get('content-type')), 'GET /pico.min.css → 200 text/css');
  for (const u of ['/nonesiste.html', '/server.js', '/..%2fserver.js', '/constructor', '/toString']) {
    r = await fetch(base + u);
    ok(r.status === 404, `${u} → 404`);
  }
  r = await fetch(base + '/recuperadati', { method: 'POST', body: buono, headers: form });
  let t = await r.text();
  ok(r.status === 200 && /Dati ricevuti/.test(t) && /Niccolò/.test(t) && /D'Amico/.test(t), 'POST valido → 200, i valori tornano in pagina');
  r = await fetch(base + '/recuperadati', { method: 'POST', body: cattivo, headers: form });
  t = await r.text();
  const errori = (t.match(/<li>/g) || []).length;
  ok(r.status === 400 && errori === 7, `POST non valido → 400 con 7 errori (trovati ${errori})`);
  r = await fetch(base + '/recuperadati', { method: 'POST', body: nessunContatto, headers: form });
  t = await r.text();
  ok(r.status === 400 && /almeno uno tra/.test(t), 'gruppo email/telefono vuoto → errore unico');
  r = await fetch(base + '/recuperadati?cognome=Rossi&cognome=Bianchi&nome=Anna');
  ok(r.status === 400, 'name ripetuto in un campo di testo: risposta 400, il server non cade');
  r = await fetch(base + '/recuperadati?' + buono);
  ok(r.status === 200, 'GET valido → 200');
  r = await fetch(base + '/recuperadati?' + cattivo);
  ok(r.status === 400, 'GET non valido → 400');
  const extra = async (q, atteso, msg) => { const rr = await fetch(base + '/recuperadati?' + new URLSearchParams(Object.assign(Object.fromEntries(buono), q))); ok(rr.status === atteso, msg + ` (${rr.status})`); };
  await extra({ sesso: 'f' }, 200, 'elenco: «f» accettato');
  await extra({ sesso: 'X' }, 400, 'elenco: «X» rifiutato');
  await extra({ email: 'a@b.it', conferma: 'a@b.it' }, 200, 'uguale: conferma identica accettata');
  await extra({ email: 'a@b.it', conferma: 'b@b.it' }, 400, 'uguale: conferma diversa rifiutata');
  await extra({ tutore: '01/01/1980' }, 200, 'maggiorenne: 1980 accettato');
  const quest = new Date(); const minorenne = `01/01/${quest.getFullYear() - 10}`;
  await extra({ tutore: minorenne }, 400, 'maggiorenne: dieci anni rifiutato');
  await extra({ tutore: '31/02/1980' }, 400, 'maggiorenne: data inesistente rifiutata');
  r = await fetch(base + '/');
  ok(r.status === 200, 'dopo le richieste strane il server risponde ancora');
} finally {
  proc.kill();
}

// ---------------------------------------------------------------- menu, radio, caselle, textarea
console.log('Tipi di campo');
const specTipi = {
  titolo: 'Iscrizione', azione: '/recuperadati', metodo: 'get',
  campi: [
    { etichetta: 'Provincia', nome: 'provincia', tipo: 'menu', opzioni: P.PRESET.province, presenza: 'obbligatorio' },
    { etichetta: 'Sesso', nome: 'sesso', tipo: 'radio', opzioni: P.PRESET.sesso, presenza: 'obbligatorio' },
    { etichetta: 'Hobby', nome: 'hobby', tipo: 'caselle', opzioni: 'calcio = Calcio\nmusica = Musica\nlettura = Lettura', presenza: 'facoltativo', max: '2' },
    { etichetta: 'Accetto il regolamento', nome: 'privacy', tipo: 'casella', presenza: 'obbligatorio' },
    { etichetta: 'Note', nome: 'note', tipo: 'area', righe: '12', colonne: '60', presenza: 'facoltativo', max: '200' },
  ],
};
const htmlTipi = P.generaHtml(specTipi);
ok(/<select id="provincia" name="provincia">\s*<option value="">Scegli…<\/option>/.test(htmlTipi), 'HTML: menu con la voce vuota «Scegli…»');
ok((htmlTipi.match(/<option value="[A-Z]{2}">/g) || []).length === 107, 'HTML: 107 province');
ok(/type="radio" name="sesso" value="M"> Maschio/.test(htmlTipi) && /<legend>Sesso<\/legend>/.test(htmlTipi), 'HTML: radio in un fieldset con legend');
ok((htmlTipi.match(/type="checkbox" name="hobby"/g) || []).length === 3, 'HTML: tre caselle con lo stesso name');
ok(/<textarea id="note" name="note" rows="12" cols="60">/.test(htmlTipi), 'HTML: textarea 12 righe per 60 colonne');
ok(!/required|pattern=|type="(email|number|date|tel|url)"/.test(htmlTipi), 'HTML: nessun tipo HTML5 e nessun required');
let serverTipi = P.generaServer(specTipi, MODELLO);
const PORTA2 = PORTA + 1;
serverTipi = serverTipi.replace(/const port = \d+;/, `const port = ${PORTA2};`);
const dir2 = mkdtempSync(join(tmpdir(), 'pettine-tipi-'));
writeFileSync(join(dir2, 'server.js'), serverTipi);
writeFileSync(join(dir2, 'index.html'), htmlTipi);
const proc2 = spawn('node', ['server.js'], { cwd: dir2 });
await new Promise((ris, rif) => {
  proc2.stdout.on('data', d => /running/.test(d) && ris());
  proc2.stderr.on('data', d => rif(new Error(d.toString())));
  setTimeout(() => rif(new Error('timeout avvio')), 4000);
});
const b2 = `http://127.0.0.1:${PORTA2}/recuperadati`;
const prova = async (q, atteso, msg, metodo) => {
  const r = metodo === 'POST'
    ? await fetch(b2, { method: 'POST', body: q, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })
    : await fetch(b2 + '?' + q);
  const t = await r.text();
  ok(r.status === atteso, `${msg} (${r.status})`);
  return t;
};
try {
  let t = await prova('provincia=PR&sesso=F&hobby=calcio&hobby=musica&privacy=si&note=ciao', 200, 'GET: tutto valido, due hobby');
  ok(/calcio,musica/.test(t), 'GET: le due caselle arrivano entrambe (qs.parse)');
  t = await prova('provincia=PR&sesso=M&hobby=lettura&hobby=calcio&privacy=si', 200, 'POST: tutto valido, due hobby', 'POST');
  ok(/lettura,calcio/.test(t), 'POST: le due caselle arrivano entrambe');
  await prova('provincia=&sesso=F&privacy=si', 400, 'menu: nessuna provincia scelta rifiutata');
  await prova('provincia=XX&sesso=F&privacy=si', 400, 'menu: provincia fuori elenco rifiutata');
  await prova('provincia=PR&sesso=X&privacy=si', 400, 'radio: valore fuori elenco rifiutato');
  await prova('provincia=PR&sesso=F&hobby=sci&privacy=si', 400, 'caselle: valore fuori elenco rifiutato');
  await prova('provincia=PR&sesso=F&hobby=calcio&hobby=musica&hobby=lettura&privacy=si', 400, 'caselle: più del massimo rifiutato');
  await prova('provincia=PR&sesso=F', 400, 'casella obbligatoria non spuntata rifiutata');
  await prova('provincia=PR&sesso=F&privacy=si&note=' + 'x'.repeat(201), 400, 'textarea: oltre 200 caratteri rifiutata');
} finally {
  proc2.kill();
}

// ---------------------------------------------------------------- esempio completo avviato
console.log('Esempio completo avviato');
{
  const porta = PORTA + 9;
  const srv = P.generaServer(Object.assign({}, completo, { statici: 'readfile' }), MODELLO).replace(/const port = \d+;/, `const port = ${porta};`);
  const d = mkdtempSync(join(tmpdir(), 'pettine-completo-'));
  writeFileSync(join(d, 'server.js'), srv);
  writeFileSync(join(d, 'index.html'), P.generaHtml(completo));
  const pr = spawn('node', ['server.js'], { cwd: d });
  await new Promise((ris, rif) => { pr.stdout.on('data', x => /running/.test(x) && ris()); pr.stderr.on('data', x => rif(new Error(x.toString()))); setTimeout(() => rif(new Error('timeout')), 4000); });
  const b = `http://127.0.0.1:${porta}`;
  try {
    let r = await fetch(b + '/recuperadati', { method: 'POST', body: '', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
    let t = await r.text();
    ok(r.status === 400 && (t.match(/<li>/g) || []).length > 20, 'POST vuoto → 400 con un errore per ogni campo obbligatorio');
    r = await fetch(b + '/recuperadati?hobby=calcio&hobby=musica&linguaggi=html');
    t = await r.text();
    ok(r.status === 400 && !/Hobby.*valore non ammesso/.test(t), 'GET con due caselle e una voce di lista: voci accettate');
    r = await fetch(b + '/recuperadati?hobby=sci');
    t = await r.text();
    ok(/«Hobby»: c'è un valore non ammesso/.test(t), 'casella fuori elenco: errore');
    r = await fetch(b + '/');
    ok(r.status === 200, 'il server è ancora vivo');
  } finally { pr.kill(); }
}

// ---------------------------------------------------------------- file statici: pipe, data/end, readFile
console.log('File statici');
for (const [k, modo] of ['pipe', 'eventi', 'readfile'].entries()) {
  const specM = Object.assign({}, specTipi, { statici: modo });
  let srv = P.generaServer(specM, MODELLO);
  ok(!/readFileSync\s*\(/.test(srv), `${modo}: niente readFileSync`);
  ok(modo === 'readfile' ? /fs\.readFile\(filePath, function \(error, data\)/.test(srv) : /fs\.createReadStream\(filePath\)/.test(srv), `${modo}: il metodo giusto nel codice`);
  ok(modo !== 'eventi' || (/on\('data'/.test(srv) && /on\('end'/.test(srv) && !/\.pipe\(res\)/.test(srv)), `${modo}: eventi data ed end, senza pipe`);
  const porta = PORTA + 2 + k;
  srv = srv.replace(/const port = \d+;/, `const port = ${porta};`);
  const d = mkdtempSync(join(tmpdir(), 'pettine-' + modo + '-'));
  writeFileSync(join(d, 'server.js'), srv);
  writeFileSync(join(d, 'index.html'), P.generaHtml(specM));
  writeFileSync(join(d, 'pico.min.css'), pico);
  const pr = spawn('node', ['server.js'], { cwd: d });
  await new Promise((ris, rif) => { pr.stdout.on('data', x => /running/.test(x) && ris()); pr.stderr.on('data', x => rif(new Error(x.toString()))); setTimeout(() => rif(new Error('timeout')), 4000); });
  const b = `http://127.0.0.1:${porta}`;
  try {
    let r = await fetch(b + '/'); let t = await r.text();
    ok(r.status === 200 && /text\/html/.test(r.headers.get('content-type')) && /<form/.test(t), `${modo}: / → index.html completo`);
    r = await fetch(b + '/pico.min.css'); t = await r.text();
    ok(r.status === 200 && /text\/css/.test(r.headers.get('content-type')) && t.length === pico.length, `${modo}: Pico intero, text/css`);
    r = await fetch(b + '/nonesiste'); ok(r.status === 404, `${modo}: rotta sconosciuta → 404`);
    execFileSync('rm', [join(d, 'pico.min.css')]);
    r = await fetch(b + '/pico.min.css'); ok(r.status === 404, `${modo}: file permesso ma mancante → 404 (ENOENT)`);
  } finally { pr.kill(); }
}

// ---------------------------------------------------------------- errori sotto al campo
console.log('Errori sotto al campo');
const specCampo = {
  titolo: 'Iscrizione', azione: '/recuperadati', metodo: 'post', errori: 'campo', ricompila: true,
  campi: [
    { etichetta: 'Cognome', nome: 'cognome', regola: 'nonnumerico', presenza: 'obbligatorio' },
    { etichetta: 'Matricola', nome: 'matricola', regola: 'cifre', cifre: '5', presenza: 'obbligatorio' },
    { etichetta: 'Email', nome: 'email', regola: 'email', presenza: 'gruppo' },
    { etichetta: 'Telefono', nome: 'telefono', regola: 'telefonoGen', presenza: 'gruppo' },
    { etichetta: 'Data di nascita', nome: 'data-nascita', regola: 'data', presenza: 'facoltativo' },
    { etichetta: 'Regione', nome: 'regione', tipo: 'menu', opzioni: 'si\nno', presenza: 'facoltativo' },
    { etichetta: 'Provincia', nome: 'provincia', tipo: 'menu', opzioni: P.PRESET.province, presenza: 'obbligatorio' },
    { etichetta: 'Conferma', nome: 'conferma', tipo: 'menu', opzioni: 'si\nno', presenza: 'facoltativo' },
    { etichetta: 'Sesso', nome: 'sesso', tipo: 'radio', opzioni: P.PRESET.sesso, presenza: 'obbligatorio' },
    { etichetta: 'Hobby', nome: 'hobby', tipo: 'caselle', opzioni: 'calcio\nmusica\nlettura', presenza: 'facoltativo', max: '2' },
    { etichetta: 'Accetto', nome: 'privacy', tipo: 'casella', presenza: 'obbligatorio' },
    { etichetta: 'Note', nome: 'note', tipo: 'area', presenza: 'facoltativo', max: '20' },
  ],
};
const htmlCampo = P.generaHtml(specCampo);
ok((htmlCampo.match(/<small id="errore-/g) || []).length === specCampo.campi.length, 'HTML: uno <small id="errore-..."> per campo');
ok(/aria-describedby="errore-matricola">\s*<small id="errore-matricola">5 cifre<\/small>/.test(htmlCampo) && !/-aiuto/.test(htmlCampo), 'HTML: il suggerimento sta nello stesso <small> dell\'errore');
ok(/<fieldset id="sesso">/.test(htmlCampo), 'HTML: il fieldset ha l\'id, così aria-invalid lo colora');
ok(!/<small id="errore-/.test(P.generaHtml(Object.assign({}, specCampo, { errori: 'pagina' }))), 'HTML in modalità pagina: nessuno <small> d\'errore');
for (const [ric, modo] of [[true, 'pipe'], [false, 'eventi'], [true, 'readfile']]) {
  const srv = P.generaServer(Object.assign({}, specCampo, { ricompila: ric, statici: modo }), MODELLO);
  const trovati = vietati.filter(v => srv.includes(v));
  const lunghe = srv.split('\n').filter(r => r.length > 100 && !/const RE_|errori(\.\w+|\[".*?"\]) = "/.test(r));
  ok(!trovati.length && !lunghe.length, `sotto al campo, ${modo}${ric ? ', ricompila' : ''}: stile basico${trovati.length ? ' (trovati: ' + trovati.join(' ') + ')' : ''}${lunghe.length ? '\n' + lunghe.join('\n') : ''}`);
  ok(ric === /function ricompila/.test(srv), `sotto al campo, ${modo}: ricompila ${ric ? 'presente' : 'assente'}`);
}
const completoCampo = P.generaServer(Object.assign({}, completo, { errori: 'campo', ricompila: true }), MODELLO);
ok(!vietati.some(v => completoCampo.includes(v)), 'esempio completo, sotto al campo: nessun costrutto avanzato');
{
  const porta = PORTA + 20;
  const avvia = async (spec, p) => {
    const d = mkdtempSync(join(tmpdir(), 'pettine-campo-'));
    writeFileSync(join(d, 'server.js'), P.generaServer(spec, MODELLO).replace(/const port = \d+;/, `const port = ${p};`));
    writeFileSync(join(d, 'index.html'), P.generaHtml(spec));
    writeFileSync(join(d, 'pico.min.css'), pico);
    const pr = spawn('node', ['server.js'], { cwd: d });
    await new Promise((ris, rif) => { pr.stdout.on('data', x => /running/.test(x) && ris()); pr.stderr.on('data', x => rif(new Error(x.toString()))); setTimeout(() => rif(new Error('timeout')), 4000); });
    return pr;
  };
  const invia = (p, corpo) => fetch(`http://127.0.0.1:${p}/recuperadati`, { method: 'POST', body: corpo, headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
  const pr = await avvia(specCampo, porta);
  try {
    let r = await invia(porta, 'cognome=Rossi&matricola=12a&email=&telefono=&data-nascita=31%2F02%2F2000&regione=no&provincia=PR&conferma=si&sesso=F&hobby=calcio&hobby=lettura&note=ciao+a+tutti');
    let t = await r.text();
    ok(r.status === 400 && /<form/.test(t), 'dati non validi → 400 con il form, non una pagina a parte');
    ok(/<small id="errore-matricola">«Matricola» deve essere un numero di 5 cifre\.<\/small>/.test(t), 'messaggio al posto del suggerimento, sotto Matricola');
    ok(/id="matricola" name="matricola" value="12a" aria-describedby/.test(t) || /id="matricola" aria-invalid="true" name="matricola" value="12a"/.test(t), 'Matricola: aria-invalid e valore ricompilato');
    ok(/<small id="errore-email">Compila almeno uno tra/.test(t), 'errore di gruppo sotto il primo campo del gruppo');
    ok(/<small id="errore-data-nascita">«Data di nascita»/.test(t) && /id="data-nascita" aria-invalid="true"/.test(t), 'name con il trattino: errore e aria-invalid al posto giusto');
    ok(/<small id="errore-cognome"><\/small>/.test(t) && /name="cognome" value="Rossi"/.test(t), 'campo valido: nessun messaggio, valore ricompilato');
    ok(/<option value="PR" selected>/.test(t), 'menu: provincia ricompilata');
    const regione = t.slice(t.indexOf('<select id="regione"'), t.indexOf('</select>', t.indexOf('<select id="regione"')));
    const conferma = t.slice(t.indexOf('<select id="conferma"'), t.indexOf('</select>', t.indexOf('<select id="conferma"')));
    ok(/value="no" selected/.test(regione) && !/value="si" selected/.test(regione) && /value="si" selected/.test(conferma) && !/value="no" selected/.test(conferma), 'due menu con gli stessi valori: ognuno prende il suo');
    ok(/name="sesso" value="F" checked/.test(t) && !/name="sesso" value="M" checked/.test(t), 'radio ricompilato');
    ok(/name="hobby" value="calcio" checked/.test(t) && /name="hobby" value="lettura" checked/.test(t) && !/value="musica" checked/.test(t), 'caselle ricompilate');
    ok(/<textarea id="note" name="note">ciao a tutti<\/textarea>/.test(t), 'area di testo ricompilata');
    ok(/<small id="errore-privacy">Spunta la casella/.test(t), 'casella obbligatoria non spuntata: messaggio sotto');
    r = await invia(porta, 'cognome=Rossi&matricola=12345&email=a%40b.it&provincia=PR&sesso=M&privacy=si');
    t = await r.text();
    ok(r.status === 200 && /Dati ricevuti/.test(t), 'dati validi → 200, la pagina di conferma resta quella di prima');
    r = await invia(porta, 'cognome=Rossi&cognome=Bianchi&hobby=sci');
    ok(r.status === 400, 'name ripetuto e casella fuori elenco: 400, il server non cade');
    r = await fetch(`http://127.0.0.1:${porta}/pico.min.css`);
    ok(r.status === 200, 'file statici serviti come prima');
  } finally { pr.kill(); }
  const pr2 = await avvia(Object.assign({}, specCampo, { ricompila: false, statici: 'readfile' }), porta + 1);
  try {
    const r = await invia(porta + 1, 'cognome=Rossi&matricola=12a&provincia=PR&sesso=F');
    const t = await r.text();
    ok(r.status === 400 && /<small id="errore-matricola">«Matricola»/.test(t) && !/value="Rossi"/.test(t) && !/selected/.test(t), 'senza ricompila: errori sotto i campi, form vuoto');
  } finally { pr2.kill(); }
}

// ---------------------------------------------------------------- regressione
console.log('Regressione (errori su pagina)');
let regressione = true;
try { execFileSync('node', [join(radice, 'tests/regressione.mjs')]); } catch (e) { regressione = false; console.log(e.stdout.toString()); }
ok(regressione, 'modalità «errori su pagina» identica ai riferimenti in tests/riferimenti');

console.log(ko ? `\n${ko} prove fallite` : '\nTutte le prove passate');
process.exit(ko ? 1 : 0);
