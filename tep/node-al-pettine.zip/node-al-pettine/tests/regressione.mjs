// Regressione: con gli errori su pagina separata (il comportamento storico) il codice generato
// deve restare identico, byte per byte, ai file salvati in tests/riferimenti.
// Uso: node tests/regressione.mjs            confronta
//      node tests/regressione.mjs --aggiorna  riscrive i riferimenti (solo dopo un cambio voluto)
import { createRequire } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const radice = join(dirname(fileURLToPath(import.meta.url)), '..');
const P = require(join(radice, 'lib/genera.js'));
const MODELLO = readFileSync(join(radice, 'lib/server.tpl.js'), 'utf8');
const cartella = join(radice, 'tests/riferimenti');

// Il form Contatti di partenza del tool (app/tool.js, esempio()).
const contatti = {
  titolo: 'Contatti', azione: '/recuperadati', metodo: 'post', statici: 'pipe', bottone: 'Invia', reset: true, porta: 3000,
  campi: [
    { etichetta: 'Cognome', nome: 'cognome', regola: 'nonnumerico', presenza: 'obbligatorio' },
    { etichetta: 'Nome', nome: 'nome', regola: 'nonnumerico', presenza: 'obbligatorio' },
    { etichetta: 'Matricola', nome: 'matricola', regola: 'cifre', cifre: '5', presenza: 'obbligatorio' },
    { etichetta: 'Email', nome: 'email', regola: 'email', presenza: 'gruppo' },
    { etichetta: 'Telefono', nome: 'telefono', regola: 'telefonoGen', presenza: 'gruppo' },
    { etichetta: 'Data di nascita', nome: 'data_di_nascita', regola: 'data', presenza: 'facoltativo' },
  ],
};
// Un campo per ogni regola, con nomi scomodi (trattino) e tutti i parametri.
const tutte = {
  titolo: 'Tutte le regole', azione: '/recuperadati', metodo: 'get',
  campi: Object.keys(P.REGOLE).map((r, i) => ({ etichetta: 'Campo ' + i, nome: i === 3 ? 'campo-' + i : 'c' + i, regola: r, presenza: ['obbligatorio', 'facoltativo', 'gruppo'][i % 3], min: '1', max: '9', cifre: '5', anni: '18', valori: 'M, F', campo: 'c0', pattern: '[a-z]+', messaggio: 'Formato non valido.' })),
};
const completo = P.esempioCompleto();

const casi = {};
for (const modo of ['pipe', 'eventi', 'readfile']) {
  casi['contatti-' + modo] = Object.assign({}, contatti, { statici: modo });
  casi['completo-' + modo] = Object.assign({}, completo, { statici: modo });
}
casi['contatti-get-scuro'] = Object.assign({}, contatti, { metodo: 'get', tema: 'dark', reset: false, azione: '/invia' });
casi['tutte-le-regole'] = tutte;

const aggiorna = process.argv.includes('--aggiorna');
let ko = 0, n = 0;
// Ogni caso due volte: senza l'opzione (default) e con errori: 'pagina' esplicito, dove ricompila va ignorato.
const varianti = [['', {}], [' (errori: pagina)', { errori: 'pagina', ricompila: true }]];
for (const [nomeCaso, specBase] of Object.entries(casi)) for (const [etichetta, extra] of varianti) {
  if (aggiorna && etichetta) continue;
  const spec = Object.assign({}, specBase, extra), nome = nomeCaso + etichetta;
  const file = { 'index.html': P.generaHtml(spec), 'server.js': P.generaServer(spec, MODELLO) };
  for (const [f, testo] of Object.entries(file)) {
    const percorso = join(cartella, `${nomeCaso}.${f}`);
    n++;
    if (aggiorna) { writeFileSync(percorso, testo); continue; }
    if (!existsSync(percorso)) { ko++; console.log(`  KO  ${nome}/${f}: riferimento mancante`); continue; }
    const atteso = readFileSync(percorso, 'utf8');
    if (atteso === testo) { console.log(`  ok  ${nome}/${f} identico`); continue; }
    ko++;
    const a = atteso.split('\n'), b = testo.split('\n');
    const riga = a.findIndex((r, i) => r !== b[i]);
    console.log(`  KO  ${nome}/${f} cambiato dalla riga ${riga + 1}\n      prima: ${a[riga]}\n      ora:   ${b[riga]}`);
  }
}
if (aggiorna) console.log(`${n} riferimenti scritti in tests/riferimenti`);
else console.log(ko ? `\n${ko} file cambiati: la modalità «errori su pagina» non è più quella di prima` : `\nRegressione: ${n} file identici ai riferimenti`);
process.exit(ko ? 1 : 0);
