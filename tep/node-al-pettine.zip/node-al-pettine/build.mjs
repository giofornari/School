
// Costruisce dist/node-al-pettine.html: un solo file, tutto incorporato, funziona offline.
// Uso: node build.mjs
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const qui = dirname(fileURLToPath(import.meta.url));
const leggi = p => readFileSync(join(qui, p), 'utf8');

// I testi incorporati diventano stringhe JS con < e > in forma \u003c / \u003e:
// nessun tag e nessun commento HTML può comparire dentro lo <script>.
const stringa = t => JSON.stringify(t).replace(/</g, '\\u003c').replace(/>/g, '\\u003e');
const tpl = stringa(leggi('lib/server.tpl.js'));
const js = [
  leggi('lib/genera.js'),
  leggi('lib/zip.js'),
  `const SERVER_TPL = ${tpl};`,
  `window.PICO_CSS = ${stringa(leggi('vendor/pico.min.css'))};`,
  leggi('app/tool.js'),
].join('\n');
// Il JS sta dentro <!-- ... //--> : se un'anteprima toglie i tag <script> senza eseguirli,
// il codice resta un commento invisibile invece di comparire come testo.
for (const vietato of [/<\/?script/i, /<!--/, /-->/, /--!>/]) {
  if (vietato.test(js)) throw new Error(`Il JS contiene ${vietato}: il file finale si romperebbe`);
}

const css = leggi('app/style.css');

const pagina = leggi('app/index.html')
  .replace('/*@@CSS@@*/', () => css)
  .replace('/*@@JS@@*/', () => '<!--\n' + js + '\n//-->');

mkdirSync(join(qui, 'dist'), { recursive: true });
writeFileSync(join(qui, 'dist/node-al-pettine.html'), pagina);
console.log(`dist/node-al-pettine.html  ${Math.round(pagina.length / 1024)} KB`);
